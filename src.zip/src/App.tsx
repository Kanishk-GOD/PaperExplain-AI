import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { AnalysisInterface } from './components/AnalysisInterface';
import { UploadModal } from './components/UploadModal';
import { SettingsModal } from './components/SettingsModal';
import { DocumentRecord, ExplanationMode, AppSettings } from './types/document';
import {
  loadDocuments,
  saveDocuments,
  loadSettings,
  saveSettings,
  clearAllDocuments
} from './services/supabaseClient';

export function App() {
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);
  const [activeDocument, setActiveDocument] = useState<DocumentRecord | null>(null);
  const [currentView, setCurrentView] = useState<'dashboard' | 'analysis'>('dashboard');
  const [currentMode, setCurrentMode] = useState<ExplanationMode>('simple');
  const [settings, setSettings] = useState<AppSettings>(loadSettings());

  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  useEffect(() => {
    const loadedDocs = loadDocuments();
    setDocuments(loadedDocs);
    if (loadedDocs.length > 0) {
      setActiveDocument(loadedDocs[0]);
    } else {
      setActiveDocument(null);
    }
    const loadedSets = loadSettings();
    setSettings(loadedSets);
    setCurrentMode(loadedSets.defaultMode || 'simple');
  }, []);

  const handleModeChange = (mode: ExplanationMode) => {
    setCurrentMode(mode);
    if (activeDocument) {
      const updated = { ...activeDocument, currentMode: mode };
      setActiveDocument(updated);
      const updatedList = documents.map((d) => (d.id === activeDocument.id ? updated : d));
      setDocuments(updatedList);
      saveDocuments(updatedList);
    }
  };

  const handleSelectDocument = (doc: DocumentRecord) => {
    setActiveDocument(doc);
    setCurrentMode(doc.currentMode || currentMode);
    setCurrentView('analysis');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleUpdateDocument = (updated: DocumentRecord) => {
    setActiveDocument(updated);
    const updatedList = documents.map((d) => (d.id === updated.id ? updated : d));
    setDocuments(updatedList);
    saveDocuments(updatedList);
  };

  const handleDeleteDocument = (id: string) => {
    const updatedList = documents.filter((d) => d.id !== id);
    setDocuments(updatedList);
    saveDocuments(updatedList);
    if (activeDocument?.id === id) {
      setActiveDocument(updatedList[0] || null);
      if (updatedList.length === 0) setCurrentView('dashboard');
    }
  };

  const handleDocumentCreated = (newDoc: DocumentRecord) => {
    const updatedList = [newDoc, ...documents];
    setDocuments(updatedList);
    saveDocuments(updatedList);
    handleSelectDocument(newDoc);
  };

  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
    setCurrentMode(newSettings.defaultMode);
  };

  const handleClearAll = () => {
    const freshDocs = clearAllDocuments();
    setDocuments(freshDocs);
    setActiveDocument(freshDocs[0] || null);
    setCurrentView('dashboard');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#ffffff] text-[#1d1d1f] font-['SF_Pro_Display'] selection:bg-[#0071e3]/10 selection:text-[#0071e3]">
      
      {/* Top Apple Navigation */}
      <Navbar
        currentView={currentView}
        onNavigate={setCurrentView}
        activeDocument={activeDocument}
        documents={documents}
        onSelectDocument={handleSelectDocument}
        currentMode={currentMode}
        onChangeMode={handleModeChange}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        hasApiKey={Boolean(settings.geminiApiKey && settings.geminiApiKey.length > 5)}
      />

      {/* Main View */}
      <main className="flex-1 pb-16">
        {currentView === 'dashboard' ? (
          <Dashboard
            documents={documents}
            onSelectDocument={handleSelectDocument}
            onOpenUpload={() => setIsUploadOpen(true)}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onDeleteDocument={handleDeleteDocument}
          />
        ) : activeDocument ? (
          <AnalysisInterface
            document={activeDocument}
            currentMode={currentMode}
            onChangeMode={handleModeChange}
            onUpdateDocument={handleUpdateDocument}
            geminiApiKey={settings.geminiApiKey}
            geminiModel={settings.geminiModel}
          />
        ) : (
          <div className="max-w-md mx-auto py-20 text-center space-y-4">
            <p className="text-sm text-[#86868b]">No document selected.</p>
            <button
              onClick={() => setCurrentView('dashboard')}
              className="apple-btn-primary"
            >
              Back to Dashboard
            </button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#e5e7eb] bg-[#f5f5f7] py-6 px-4 text-center text-xs text-[#86868b]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-semibold text-[#1d1d1f]">
            PaperExplain AI — Personal Document Understanding
          </p>
          <p className="text-[#86868b]">
            "Upload any document. Understand everything."
          </p>
        </div>
      </footer>

      {/* Modals */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onDocumentCreated={handleDocumentCreated}
        geminiApiKey={settings.geminiApiKey}
        geminiModel={settings.geminiModel}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onResetSampleData={handleClearAll}
      />

    </div>
  );
}
export default App;
