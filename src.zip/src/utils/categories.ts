import { DocumentCategory } from '../types/document';

export interface CategoryMeta {
  id: DocumentCategory;
  name: string;
  badge: string;
  color: string;
  textColor: string;
  borderColor: string;
  bgSubtle: string;
  iconName: string;
  description: string;
  exampleTypes: string[];
}

export const CATEGORIES_CONFIG: Record<DocumentCategory, CategoryMeta> = {
  legal: {
    id: 'legal',
    name: 'Legal & Contracts',
    badge: 'Legal',
    color: '#818cf8',
    textColor: 'text-indigo-800',
    borderColor: 'border-indigo-200',
    bgSubtle: 'bg-indigo-50',
    iconName: 'Scale',
    description: 'Bilateral contracts, NDAs, power of attorney, settlements, legal notices',
    exampleTypes: ['Commercial Contract', 'Settlement Agreement', 'Non-Disclosure Agreement', 'Power of Attorney']
  },
  employment: {
    id: 'employment',
    name: 'Employment & Offers',
    badge: 'Employment',
    color: '#0284c7',
    textColor: 'text-sky-800',
    borderColor: 'border-sky-200',
    bgSubtle: 'bg-sky-50',
    iconName: 'Briefcase',
    description: 'Offer letters, employment agreements, IP assignments, severance packets',
    exampleTypes: ['Employment Agreement', 'Offer Letter', 'Non-Compete Deed', 'Stock Option Grant']
  },
  property: {
    id: 'property',
    name: 'Property & Real Estate',
    badge: 'Property',
    color: '#d97706',
    textColor: 'text-amber-800',
    borderColor: 'border-amber-200',
    bgSubtle: 'bg-amber-50',
    iconName: 'Home',
    description: 'Lease deeds, tenancy agreements, mortgage covenants, purchase contracts',
    exampleTypes: ['Commercial Lease Deed', 'Residential Tenancy Agreement', 'Mortgage Deed', 'Sale Deed']
  },
  insurance: {
    id: 'insurance',
    name: 'Insurance Policies',
    badge: 'Insurance',
    color: '#059669',
    textColor: 'text-emerald-800',
    borderColor: 'border-emerald-200',
    bgSubtle: 'bg-emerald-50',
    iconName: 'ShieldAlert',
    description: 'Health, term life, vehicle, property insurance policies and claim schedules',
    exampleTypes: ['Health Insurance Policy', 'Motor Comprehensive Cover', 'Term Life Plan', 'Disability Policy']
  },
  financial: {
    id: 'financial',
    name: 'Financial & Banking',
    badge: 'Financial',
    color: '#10b981',
    textColor: 'text-teal-800',
    borderColor: 'border-teal-200',
    bgSubtle: 'bg-teal-50',
    iconName: 'Banknote',
    description: 'Loan agreements, credit facilities, bank statements, investment prospectuses',
    exampleTypes: ['Loan Agreement', 'Credit Facility Agreement', 'Quarterly Financial Statement', 'Investment Terms']
  },
  medical: {
    id: 'medical',
    name: 'Medical & Healthcare',
    badge: 'Medical',
    color: '#e11d48',
    textColor: 'text-rose-800',
    borderColor: 'border-rose-200',
    bgSubtle: 'bg-rose-50',
    iconName: 'Stethoscope',
    description: 'Diagnostic laboratory reports, discharge summaries, biopsy & genomic reports',
    exampleTypes: ['Clinical Lab Report', 'Genomic Biopsy Analysis', 'Hospital Discharge Summary', 'Pathology Report']
  },
  academic: {
    id: 'academic',
    name: 'Academic & Research',
    badge: 'Academic',
    color: '#7c3aed',
    textColor: 'text-purple-800',
    borderColor: 'border-purple-200',
    bgSubtle: 'bg-purple-50',
    iconName: 'GraduationCap',
    description: 'Peer-reviewed papers, conference proceedings, dissertations, clinical trial papers',
    exampleTypes: ['Research Paper', 'Conference Preprint', 'System Architecture Whitepaper', 'Dissertation']
  },
  business: {
    id: 'business',
    name: 'Business Reports & MSAs',
    badge: 'Business',
    color: '#2563eb',
    textColor: 'text-blue-800',
    borderColor: 'border-blue-200',
    bgSubtle: 'bg-blue-50',
    iconName: 'Building2',
    description: 'Master services agreements, vendor contracts, business proposals, SLA schedules',
    exampleTypes: ['Master Services Agreement (MSA)', 'SLA Agreement', 'Partnership MoU', 'Vendor Services Contract']
  },
  government: {
    id: 'government',
    name: 'Government & Compliance',
    badge: 'Government',
    color: '#475569',
    textColor: 'text-slate-800',
    borderColor: 'border-slate-200',
    bgSubtle: 'bg-slate-50',
    iconName: 'Landmark',
    description: 'Regulatory orders, municipal notices, tax assessments, gazettes, grant terms',
    exampleTypes: ['Regulatory Compliance Notice', 'Government Grant Framework', 'Municipal Zoning Notice', 'Tax Order']
  },
  invoices: {
    id: 'invoices',
    name: 'Invoices & Receipts',
    badge: 'Invoices',
    color: '#0891b2',
    textColor: 'text-cyan-800',
    borderColor: 'border-cyan-200',
    bgSubtle: 'bg-cyan-50',
    iconName: 'Receipt',
    description: 'Commercial tax invoices, billing statements, purchase orders, reimbursement bills',
    exampleTypes: ['Commercial Tax Invoice', 'Billing Statement', 'Purchase Order', 'Contractor Bill']
  },
  terms: {
    id: 'terms',
    name: 'Terms & Conditions',
    badge: 'Terms',
    color: '#9333ea',
    textColor: 'text-fuchsia-800',
    borderColor: 'border-fuchsia-200',
    bgSubtle: 'bg-fuchsia-50',
    iconName: 'FileText',
    description: 'Software Terms of Service, Privacy Policies, End User License Agreements (EULA)',
    exampleTypes: ['SaaS Terms of Service', 'Privacy Policy', 'End-User License Agreement', 'Cookie Policy']
  },
  general: {
    id: 'general',
    name: 'General Documents',
    badge: 'General',
    color: '#4b5563',
    textColor: 'text-stone-800',
    borderColor: 'border-stone-200',
    bgSubtle: 'bg-stone-50',
    iconName: 'Files',
    description: 'General memos, articles, whitepapers, instructions, letters, miscellaneous PDFs',
    exampleTypes: ['General Document', 'Informational Memo', 'Guideline Handbook', 'Summary Letter']
  }
};
