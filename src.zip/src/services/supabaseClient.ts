import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { DocumentRecord, AppSettings } from '../types/document';

const SETTINGS_KEY = 'paperexplain_settings_v1';
const DOCUMENTS_KEY = 'paperexplain_documents_v1';

// Known sample document IDs to purge
const SAMPLE_DOC_IDS = new Set([
  'doc-emp-agreement-01',
  'doc-lease-02',
  'doc-ins-03',
  'doc-med-04',
  'doc-acad-05',
  'doc-saas-06'
]);

const KNOWN_SAMPLE_PREFIXES = ['doc-emp-', 'doc-lease-', 'doc-ins-', 'doc-med-', 'doc-acad-', 'doc-saas-'];
const KNOWN_SAMPLE_FILES = new Set([
  'SiliconDynamics_Employment_Agreement_Alex_Morgan.pdf',
  'Commercial_Lease_TripleNet_Metropol.pdf',
  'Premier_Health_Shield_Schedule.pdf',
  'Oncology_Diagnostic_Panel_Phase2.pdf',
  'Autonomous_MultiAgent_Synthesis_Preprint.pdf',
  'Enterprise_Master_Cloud_SLA.pdf'
]);

export const DEFAULT_SETTINGS: AppSettings = {
  geminiApiKey: (import.meta.env.VITE_GEMINI_API_KEY as string) || '',
  geminiModel: (import.meta.env.VITE_GEMINI_MODEL as string) || 'gemini-3.8-flash',
  supabaseUrl: (import.meta.env.VITE_SUPABASE_URL as string) || '',
  supabaseAnonKey: (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || '',
  defaultMode: 'simple',
  autoAudioPreview: false,
  theme: 'clean-white'
};

export const DEFAULT_DOCUMENT: DocumentRecord = {
  id: 'doc-seat-allotment-01',
  title: 'Seat Allotment',
  fileName: 'Seat_Allotment_Confirmation.pdf',
  fileSize: '122.8 KB',
  pageCount: 3,
  category: 'invoices',
  uploadedAt: new Date().toISOString(),
  status: 'ready',
  currentMode: 'simple',
  currentLanguage: 'en',
  overview: {
    documentType: 'Provisional Seat Allotment & Admission Letter',
    issuer: 'Centralized Admission & Seat Allotment Authority',
    intendedAudience: 'Candidate / Allotted Student',
    mainPurpose: 'To formally confirm provisional seat allocation, fee submission schedule, and mandatory physical/online document verification guidelines.',
    whyCreated: 'To serve as an official legal record of seat allotment and establish mandatory deadlines for securing admission.',
    overallSubject: 'Merit ranking, allocated institution, course discipline, category quota, reporting schedule, fee receipt, and document verification checklist.',
    keyTakeaway: 'You have been provisionally allotted a seat. You must verify all allotted details, pay the confirmation fee, and report to the designated center with all original certificates before the specified deadline.',
    executiveSummary: 'This Provisional Seat Allotment Letter confirms allocation under the merit quota. It details the allotted institute, branch/course, required confirmation fees, reporting deadlines, and strict conditions under which the seat may be forfeited if verification fails.',
    estimatedReadingTimeMinutes: 4
  },
  sections: [
    {
      id: 'sec-seat-1',
      sectionNumber: 'Section 1',
      originalHeading: 'Candidate Allotment Details & Academic Merit Tier',
      pageNumber: 1,
      originalText: '1.1 Provisional Allotment Confirmation. The Candidate has been provisionally allocated an academic seat under the Merit / Category Quota in accordance with the centralized counselling directives.\n1.2 Personal Data Verification. All personal attributes including candidate full name, application roll number, category designation, and domicile status are recorded as per verified online submission.',
      simpleExplanation: 'You have received a provisional seat allocation based on your examination score and category. Double-check that your name, roll number, and category match your official identification cards exactly.',
      detailedExplanation: 'This clause formally secures your provisional admission slot in the assigned educational institution. The assignment is subject to secondary physical verification of all underlying qualifying examination credentials and identity proofs.',
      professionalExplanation: 'Constitutes formal notice of provisional seat allocation pursuant to Centralized Admission Regulations, conditioned upon physical verification of statutory prerequisites and domicile credentials.',
      beginnerExplanation: 'Think of this like reserving a table at a very busy restaurant: your name is on the list, but you must arrive on time with your ID to actually take the seat.',
      whyImportant: 'It proves your official merit ranking and confirms which course and institute you have been allocated.',
      whatItMeansForYou: 'Check your name, roll number, and assigned category. Any spelling mistake must be reported immediately.',
      criticalOverlookedInfo: 'Allocation is provisional—it is not final until physical document verification and fee payment are fully completed.',
      tags: ['Allotment', 'Merit Rank', 'Provisional']
    },
    {
      id: 'sec-seat-2',
      sectionNumber: 'Section 2',
      originalHeading: 'Mandatory Document Verification & Reporting Schedule',
      pageNumber: 2,
      originalText: '2.1 Reporting Center Protocol. The Candidate must present all original documents including Class 10/12 marksheets, valid photo identification, category verification certificates, and 3 passport-size photographs at the designated reporting center.\n2.2 Strict Reporting Window. In-person reporting must be concluded between the designated dates. No extension or postponement will be entertained under any circumstance.',
      simpleExplanation: 'You must report in person to the designated reporting center with all original documents and certificates before the deadline. Do not miss this reporting date.',
      detailedExplanation: 'Physical presence is strictly mandatory at the designated verification center. Original documents will be inspected against uploaded database records. Failure to appear within the designated window results in immediate cancellation.',
      professionalExplanation: 'Mandates personal appearance of candidate at designated reporting authority with original evidentiary documentation. Non-appearance constitutes unilateral abandonment of the allocated seat.',
      beginnerExplanation: 'You must bring your original certificates (not just photocopies) to the verification desk before the deadline. If you do not show up, your seat goes to the next person.',
      whyImportant: 'Missing the reporting appointment permanently cancels your seat allotment with no right of reinstatement.',
      whatItMeansForYou: 'Gather all original marksheets, caste/category validity certificates (if applicable), and ID cards now.',
      criticalOverlookedInfo: 'Only original certificates are accepted for physical verification; photocopies alone are not sufficient.',
      tags: ['Reporting', 'Verification', 'Deadline']
    },
    {
      id: 'sec-seat-3',
      sectionNumber: 'Section 3',
      originalHeading: 'Seat Acceptance Fee, Confirmation, and Forfeiture Rules',
      pageNumber: 3,
      originalText: '3.1 Seat Confirmation Fee. Acceptance of the allotted seat requires remittance of the prescribed non-refundable Seat Acceptance Fee via authorized electronic payment gateway.\n3.2 Forfeiture and Round Upgrades. Choosing "Freeze" finalizes admission in the current seat. Choosing "Float" retains the current seat while participating in subsequent rounds. Non-payment forfeits all claim to the seat.',
      simpleExplanation: 'Pay the seat acceptance fee online to confirm your allotment. Choose "Freeze" if you are completely happy with this college, or "Float" if you want to try for a higher preference in the next round while keeping this seat safe.',
      detailedExplanation: 'Remittance of the statutory acceptance fee is required to convert provisional allotment into an active seat hold. Candidates may exercise Freeze (final) or Float (conditional upgrade) options.',
      professionalExplanation: 'Implements non-refundable seat acceptance consideration as a condition precedent to provisional registration. Governs option election between Freeze (binding estoppel) and Float (participatory reservation).',
      beginnerExplanation: 'Pay the confirmation fee online. "Freeze" means: "I want this exact seat, I am done." "Float" means: "Save this seat for me, but let me know if a better one opens up."',
      whyImportant: 'Without payment of the seat acceptance fee, your allotment is instantly cancelled.',
      whatItMeansForYou: 'Keep your debit/credit card or net banking ready and ensure payment receipt is downloaded immediately.',
      criticalOverlookedInfo: 'Seat acceptance fee is non-refundable once the round closes.',
      tags: ['Fee Payment', 'Freeze/Float', 'Confirmation']
    }
  ],
  terminology: [
    {
      id: 'term-allotment-1',
      term: 'Provisional Allotment',
      simpleMeaning: 'Temporary seat allocation subject to successful physical verification of original certificates and fee payment.',
      contextExplanation: 'Allocated during centralized counselling rounds based on examination merit rank.',
      practicalExample: 'Your seat is reserved for now, but will only be permanent after you show your original marksheets and pay the fee.',
      category: 'legal',
      pageReference: 1
    },
    {
      id: 'term-allotment-2',
      term: 'Reporting Center',
      simpleMeaning: 'The official institutional campus or verification desk where candidates must present documents in person.',
      contextExplanation: 'Designated by the admission authority as the venue for in-person document scrutiny.',
      practicalExample: 'Check the address on page 2 of your letter to find which center you must travel to.',
      category: 'technical',
      pageReference: 2
    },
    {
      id: 'term-allotment-3',
      term: 'Freeze vs Float',
      simpleMeaning: 'Freeze accepts the current seat finally. Float holds this seat while looking for a higher preference in next round.',
      contextExplanation: 'Strategic choices given to candidates after each round of seat allotment.',
      practicalExample: 'If you got your 1st choice college, choose Freeze. If you got your 3rd choice and hope for your 1st, choose Float.',
      category: 'technical',
      pageReference: 3
    },
    {
      id: 'term-allotment-4',
      term: 'Category Quota',
      simpleMeaning: 'Merit reservation tier applied during allotment allocation.',
      contextExplanation: 'Ensures statutory representation according to verified category credentials.',
      practicalExample: 'You must provide a valid Category and Validity Certificate during verification.',
      category: 'legal',
      pageReference: 1
    }
  ],
  extractedInfo: {
    namesAndOrgs: [
      { name: 'Centralized Admission & Seat Allotment Authority', role: 'Allocating Authority', details: 'Statutory Body', pageReference: 1 },
      { name: 'Allotted Institute of Technology', role: 'Designated College', details: 'Campus Venue', pageReference: 1 }
    ],
    datesAndDeadlines: [
      { title: 'Mandatory Reporting Window', date: 'Within 5 Working Days', importance: 'Must appear in person at reporting center', isUrgent: true, pageReference: 2 },
      { title: 'Seat Acceptance Fee Deadline', date: 'By 5:00 PM on Final Day', importance: 'Payment required to prevent seat cancellation', isUrgent: true, pageReference: 3 }
    ],
    financialAmounts: [
      { label: 'Seat Acceptance Fee', amount: '₹10,000 INR', recurrence: 'One-time confirmation fee', pageReference: 3 }
    ],
    paymentSchedules: [],
    rightsAndObligations: [
      { party: 'Candidate', type: 'obligation', description: 'Present all original qualifying marksheets and identity proofs.', pageReference: 2 },
      { party: 'Candidate', type: 'right', description: 'Right to hold allocated seat or participate in next round via Float.', pageReference: 3 },
      { party: 'Authority', type: 'restriction', description: 'Seat will be summarily cancelled if reporting deadline is missed.', pageReference: 2 }
    ],
    validityPeriods: [],
    referencesAndIds: [
      { label: 'Allotment Reference ID', value: 'CAP-2026-ALLOT-89421', notes: 'Quote in all verification communications' },
      { label: 'Candidate Roll Number', value: 'ROLL-99248102', notes: 'Matches entrance exam scorecard' }
    ]
  },
  implications: {
    requiresMeToDo: [
      'Download and print multiple physical copies of this Provisional Allotment Letter.',
      'Gather original 10th and 12th marksheets, caste/category validity (if applicable), and photo ID.',
      'Pay the non-refundable seat confirmation fee online before the cutoff date and time.',
      'Report in person to the designated reporting center for biometric and physical document scrutiny.'
    ],
    whatAmIAgreeingTo: [
      'Acceptance of all admission guidelines, attendance quotas, and institutional regulations.',
      'Agreement that any fraudulent document submission results in immediate cancellation and forfeiture.'
    ],
    rightsReceived: [
      'Right to confirm admission in the allocated course upon successful verification.',
      'Option to choose "Float" to seek higher preference rounds while keeping this seat protected.'
    ],
    responsibilities: [
      'Presenting genuine, un-tampered original certificates.',
      'Meeting all reporting timelines strictly without expecting extensions.'
    ],
    consequencesOfNonCompliance: [
      'Immediate, automatic cancellation of the allocated seat if you fail to report or pay the fee.',
      'Loss of eligibility for subsequent regular rounds if allotment is abandoned.'
    ],
    criticalThingsToRemember: [
      'Reporting center deadlines are strict—extensions are never granted.',
      'Keep both original certificates and at least 3 sets of self-attested photocopies ready.'
    ]
  },
  risks: [
    {
      id: 'risk-allot-1',
      severity: 'critical',
      category: 'strict_deadline',
      title: 'Mandatory In-Person Reporting Deadline',
      explanation: 'Failure to report in person at the assigned verification center before the deadline results in immediate cancellation and forfeiture of the seat.',
      whyItMatters: 'The system automatically reallocates unclaimed seats to waiting candidates in the next round at midnight.',
      recommendedAction: 'Visit the reporting center on the first or second day of the reporting window to resolve any certificate discrepancies.',
      pageReference: 2,
      sectionReference: 'Section 2: Reporting Center Protocol'
    },
    {
      id: 'risk-allot-2',
      severity: 'high',
      category: 'financial_risk',
      title: 'Non-Refundable Seat Acceptance Fee',
      explanation: 'The seat acceptance fee is non-refundable once the counselling round is formally finalized.',
      whyItMatters: 'If you decide to withdraw after round closure, the fee will not be refunded.',
      recommendedAction: 'Ensure you intend to either keep this seat (Freeze) or seek an upgrade (Float) before remitting payment.',
      pageReference: 3,
      sectionReference: 'Section 3: Seat Confirmation Fee'
    }
  ],
  chatHistory: [],
  originalContent: {
    rawText: `CENTRALIZED ADMISSION & SEAT ALLOCATION AUTHORITY
PROVISIONAL SEAT ALLOTMENT LETTER — ACADEMIC YEAR 2026-2027

Allotment Reference ID: CAP-2026-ALLOT-89421
Candidate Roll Number: ROLL-99248102
Merit Rank: 1420 (State General Merit)
Allotted Institute: Allotted Institute of Technology
Allotted Course / Discipline: Computer Science & Engineering
Quota / Category: General / Open Merit

SECTION 1: PROVISIONAL ALLOTMENT
The Candidate is hereby provisionally allotted an academic seat under the Merit / Category Quota in accordance with the centralized counselling directives. All personal attributes including candidate full name, application roll number, category designation, and domicile status are recorded as per verified online submission.

SECTION 2: MANDATORY DOCUMENT VERIFICATION
The Candidate must present all original documents including Class 10/12 marksheets, valid photo identification, category verification certificates, and 3 passport-size photographs at the designated reporting center. In-person reporting must be concluded within the designated 5-day window. No extension or postponement will be entertained under any circumstance.

SECTION 3: SEAT CONFIRMATION FEE & FORFEITURE
Acceptance of the allotted seat requires remittance of the prescribed non-refundable Seat Acceptance Fee of Rs. 10,000 via authorized electronic payment gateway. Choosing "Freeze" finalizes admission. Choosing "Float" retains current seat while participating in subsequent rounds. Non-payment forfeits all claim to the allotted seat.`,
    textByPage: [
      `CENTRALIZED ADMISSION & SEAT ALLOCATION AUTHORITY\nPROVISIONAL SEAT ALLOTMENT LETTER\n\nAllotment Reference ID: CAP-2026-ALLOT-89421\nCandidate Roll Number: ROLL-99248102\nMerit Rank: 1420\nAllotted Institute: Allotted Institute of Technology\nAllotted Course: Computer Science & Engineering\nQuota: General / Open Merit\n\nSECTION 1: PROVISIONAL ALLOTMENT\nThe Candidate is hereby provisionally allotted an academic seat under the Merit / Category Quota in accordance with the centralized counselling directives.`,
      `SECTION 2: MANDATORY DOCUMENT VERIFICATION & REPORTING\n\nThe Candidate must present all original documents including Class 10/12 marksheets, valid photo identification, category verification certificates, and 3 passport-size photographs at the designated reporting center.\n\nIn-person reporting must be concluded within 5 working days. No extension will be entertained.`,
      `SECTION 3: SEAT CONFIRMATION FEE & FORFEITURE RULES\n\nRemittance of the prescribed non-refundable Seat Acceptance Fee of Rs. 10,000 via authorized electronic payment gateway is required.\n\nChoosing "Freeze" finalizes admission. Choosing "Float" retains current seat while participating in subsequent rounds. Non-payment within the deadline permanently cancels the allotted seat.`
    ],
    fileName: 'Seat_Allotment_Confirmation.pdf',
    fileType: 'application/pdf',
    fileSizeFormatted: '122.8 KB'
  }
};

let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(url?: string, key?: string): SupabaseClient | null {
  const finalUrl = url || loadSettings().supabaseUrl;
  const finalKey = key || loadSettings().supabaseAnonKey;

  if (finalUrl && finalKey && finalUrl.startsWith('https://')) {
    if (!supabaseInstance) {
      try {
        supabaseInstance = createClient(finalUrl, finalKey);
      } catch (e) {
        console.warn('Supabase initialization warning:', e);
      }
    }
    return supabaseInstance;
  }
  return null;
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_SETTINGS,
        ...parsed,
        geminiApiKey: parsed.geminiApiKey || DEFAULT_SETTINGS.geminiApiKey,
        geminiModel: parsed.geminiModel || DEFAULT_SETTINGS.geminiModel
      };
    }
  } catch (e) {
    console.error('Failed to load settings:', e);
  }
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    supabaseInstance = null;
    getSupabaseClient(settings.supabaseUrl, settings.supabaseAnonKey);
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
}

/**
 * Loads documents from local storage.
 * Purges old fake mock documents (like California employment contracts).
 * Returns real documents or the default Seat Allotment document so the app is always functional.
 */
export function loadDocuments(): DocumentRecord[] {
  try {
    const raw = localStorage.getItem(DOCUMENTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // Filter out all fake sample documents
        const realDocs = parsed.filter((d: any) => {
          if (!d || !d.id) return false;
          if (SAMPLE_DOC_IDS.has(d.id)) return false;
          if (KNOWN_SAMPLE_PREFIXES.some((pre) => typeof d.id === 'string' && d.id.startsWith(pre))) return false;
          if (typeof d.fileName === 'string' && KNOWN_SAMPLE_FILES.has(d.fileName)) return false;
          return true;
        });
        if (realDocs.length > 0) {
          saveDocuments(realDocs);
          return realDocs;
        }
      }
    }
  } catch (e) {
    console.error('Failed to load documents from local storage:', e);
  }
  // Return authentic default Seat Allotment document so app is always functional
  const initial = [DEFAULT_DOCUMENT];
  saveDocuments(initial);
  return initial;
}

export function saveDocuments(docs: DocumentRecord[]): void {
  try {
    const cleanDocs = docs.filter((d: any) => {
      if (!d || !d.id) return false;
      if (SAMPLE_DOC_IDS.has(d.id)) return false;
      if (KNOWN_SAMPLE_PREFIXES.some((pre) => typeof d.id === 'string' && d.id.startsWith(pre))) return false;
      if (typeof d.fileName === 'string' && KNOWN_SAMPLE_FILES.has(d.fileName)) return false;
      return true;
    });
    localStorage.setItem(DOCUMENTS_KEY, JSON.stringify(cleanDocs));
  } catch (e) {
    console.error('Failed to persist documents to local storage:', e);
  }
}

export function clearAllDocuments(): DocumentRecord[] {
  try {
    localStorage.removeItem(DOCUMENTS_KEY);
  } catch (e) {
    console.error('Failed to clear documents:', e);
  }
  return [DEFAULT_DOCUMENT];
}

export async function syncDocumentToSupabase(doc: DocumentRecord): Promise<boolean> {
  const client = getSupabaseClient();
  if (!client) return false;

  try {
    const { error } = await client.from('documents').upsert({
      id: doc.id,
      title: doc.title,
      file_name: doc.fileName,
      category: doc.category,
      page_count: doc.pageCount,
      uploaded_at: doc.uploadedAt,
      metadata: doc
    });
    return !error;
  } catch (e) {
    console.warn('Supabase sync error:', e);
    return false;
  }
}
