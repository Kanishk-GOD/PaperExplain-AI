export type DocumentCategory =
  | 'legal'
  | 'government'
  | 'academic'
  | 'financial'
  | 'insurance'
  | 'employment'
  | 'business'
  | 'medical'
  | 'property'
  | 'invoices'
  | 'terms'
  | 'general';

export type ExplanationMode = 'simple' | 'detailed' | 'professional' | 'beginner';
export type ExplanationLanguage = 'en' | 'hi' | 'mr';

export interface DocumentOverview {
  documentType: string;
  issuer: string;
  intendedAudience: string;
  mainPurpose: string;
  whyCreated: string;
  overallSubject: string;
  keyTakeaway: string;
  executiveSummary: string;
  estimatedReadingTimeMinutes: number;
}

export interface DocumentSection {
  id: string;
  sectionNumber: string;
  originalHeading: string;
  pageNumber: number;
  originalText: string;
  simpleExplanation: string;
  detailedExplanation: string;
  professionalExplanation: string;
  beginnerExplanation: string;
  whyImportant: string;
  whatItMeansForYou: string;
  criticalOverlookedInfo: string;
  tags?: string[];
  keyActionRequired?: string;
}

export interface TerminologyItem {
  id: string;
  term: string;
  simpleMeaning: string;
  contextExplanation: string;
  practicalExample: string;
  category: DocumentCategory | 'technical';
  pageReference: number;
}

export interface EntityInfo {
  name: string;
  role: string;
  details: string;
  pageReference?: number;
}

export interface DateDeadline {
  title: string;
  date: string;
  importance: string;
  isUrgent?: boolean;
  pageReference?: number;
}

export interface FinancialAmount {
  label: string;
  amount: string;
  currency?: string;
  recurrence?: string;
  conditions?: string;
  pageReference?: number;
}

export interface PaymentSchedule {
  milestone: string;
  dueDate: string;
  amountOrPercentage: string;
  condition: string;
}

export interface RightOrObligation {
  party: string;
  type: 'right' | 'obligation' | 'restriction';
  description: string;
  consequenceOfBreach?: string;
  pageReference?: number;
}

export interface ValidityPeriod {
  item: string;
  period: string;
  renewalRule: string;
  cancellationRule: string;
  pageReference?: number;
}

export interface ReferenceId {
  label: string;
  value: string;
  notes?: string;
}

export interface ExtractedInformation {
  namesAndOrgs: EntityInfo[];
  datesAndDeadlines: DateDeadline[];
  financialAmounts: FinancialAmount[];
  paymentSchedules: PaymentSchedule[];
  rightsAndObligations: RightOrObligation[];
  validityPeriods: ValidityPeriod[];
  referencesAndIds: ReferenceId[];
}

export interface OverallImplications {
  requiresMeToDo: string[];
  whatAmIAgreeingTo: string[];
  rightsReceived: string[];
  responsibilities: string[];
  consequencesOfNonCompliance: string[];
  criticalThingsToRemember: string[];
}

export type RiskSeverity = 'critical' | 'high' | 'medium' | 'low' | 'info';

export type RiskCategory =
  | 'unusual_condition'
  | 'financial_risk'
  | 'restriction'
  | 'overlooked_detail'
  | 'missing_info'
  | 'contradiction'
  | 'strict_deadline';

export interface RiskAndWarning {
  id: string;
  severity: RiskSeverity;
  category: RiskCategory;
  title: string;
  explanation: string;
  whyItMatters: string;
  recommendedAction: string;
  pageReference: number;
  sectionReference: string;
}

export interface QAPair {
  id: string;
  question: string;
  answer: string;
  pageReferences: number[];
  sectionReferences: string[];
  timestamp: string;
  explanationMode: ExplanationMode;
  userPromptType?: string;
}

export interface DocumentOriginalContent {
  rawText: string;
  textByPage: string[];
  fileName: string;
  fileType: string;
  fileSizeFormatted: string;
  pdfUrl?: string; // object URL or data URL
  imageBase64?: string;
  imageMimeType?: string;
}

export interface DocumentRecord {
  id: string;
  title: string;
  fileName: string;
  fileSize: string;
  pageCount: number;
  category: DocumentCategory;
  uploadedAt: string;
  status: 'ready' | 'analyzing' | 'error';
  errorMessage?: string;
  currentMode: ExplanationMode;
  currentLanguage?: ExplanationLanguage;
  overview: DocumentOverview;
  sections: DocumentSection[];
  terminology: TerminologyItem[];
  extractedInfo: ExtractedInformation;
  implications: OverallImplications;
  risks: RiskAndWarning[];
  chatHistory: QAPair[];
  originalContent: DocumentOriginalContent;
}

export interface AppSettings {
  geminiApiKey: string;
  geminiModel: string;
  supabaseUrl: string;
  supabaseAnonKey: string;
  defaultMode: ExplanationMode;
  autoAudioPreview: boolean;
  theme: 'warm-paper' | 'clean-white' | 'dark-slate';
}
