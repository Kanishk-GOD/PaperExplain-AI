import React from 'react';
import { 
  FileText, 
  Sparkles, 
  SlidersHorizontal, 
  UploadCloud, 
  ChevronRight
} from 'lucide-react';
import { DocumentRecord, ExplanationMode } from '../types/document';

interface NavbarProps {
  currentView: 'dashboard' | 'analysis';
  onNavigate: (view: 'dashboard' | 'analysis') => void;
  activeDocument: DocumentRecord | null;
  documents: DocumentRecord[];
  onSelectDocument: (doc: DocumentRecord) => void;
  currentMode: ExplanationMode;
  onChangeMode: (mode: ExplanationMode) => void;
  onOpenUpload: () => void;
  onOpenSettings: () => void;
  hasApiKey: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  activeDocument,
  documents,
  onSelectDocument,
  currentMode,
  onChangeMode,
  onOpenUpload,
  onOpenSettings,
  hasApiKey
}) => {
  const modes: { id: ExplanationMode; label: string; dotColor: string; hint: string }[] = [
    { id: 'simple', label: 'Simple', dotColor: 'bg-emerald-500', hint: 'Plain, accessible everyday English' },
    { id: 'detailed', label: 'Detailed', dotColor: 'bg-[#0071e3]', hint: 'Comprehensive context & nuances' },
    { id: 'professional', label: 'Professional', dotColor: 'bg-purple-500', hint: 'Rigorous formal terminology' },
    { id: 'beginner', label: 'Beginner', dotColor: 'bg-amber-500', hint: 'Analogies & step-by-step examples' }
  ];

  return (
    <header className="sticky top-0 z-30 bg-[#ffffff]/90 backdrop-blur-md border-b border-[#e5e7eb] px-4 sm:px-8 py-3 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Brand & Logo */}
        <div className="flex items-center gap-8">
          <button 
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-3 group text-left focus:outline-none"
          >
            <div className="w-10 h-10 rounded-[10px] bg-[#0071e3] flex items-center justify-center text-white shadow-sm group-hover:bg-[#0077ED] transition-colors">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-['SF_Pro_Display'] font-bold text-lg tracking-tight text-[#1d1d1f]">
                  PaperExplain AI
                </span>
              </div>
              <p className="text-[12px] text-[#86868b] font-normal hidden sm:block font-['SF_Pro_Display']">
                Upload any document. Understand everything.
              </p>
            </div>
          </button>

          {/* Nav pills */}
          <nav className="hidden md:flex items-center gap-1 bg-[#f5f5f7] p-1 rounded-[980px] text-[13px] font-['SF_Pro_Display']">
            <button
              onClick={() => onNavigate('dashboard')}
              className={`px-4 py-1.5 rounded-[980px] transition-all font-medium ${
                currentView === 'dashboard'
                  ? 'bg-white text-[#1d1d1f] shadow-xs'
                  : 'text-[#86868b] hover:text-[#1d1d1f]'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => onNavigate('analysis')}
              disabled={!activeDocument}
              className={`px-4 py-1.5 rounded-[980px] transition-all flex items-center gap-1.5 font-medium ${
                currentView === 'analysis'
                  ? 'bg-white text-[#1d1d1f] shadow-xs'
                  : activeDocument
                  ? 'text-[#86868b] hover:text-[#1d1d1f]'
                  : 'text-zinc-300 cursor-not-allowed'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-[#0071e3]" />
              Analysis View
            </button>
          </nav>
        </div>

        {/* Center: Document Switcher */}
        {activeDocument && (
          <div className="hidden lg:flex items-center gap-2 max-w-xs">
            <span className="text-xs text-[#86868b] font-medium font-['SF_Pro_Display']">Document:</span>
            <select
              value={activeDocument.id}
              onChange={(e) => {
                const found = documents.find((d) => d.id === e.target.value);
                if (found) {
                  onSelectDocument(found);
                  if (currentView !== 'analysis') onNavigate('analysis');
                }
              }}
              className="text-xs font-semibold text-[#1d1d1f] bg-white border border-[#e5e7eb] rounded-[8px] px-3 py-1.5 truncate max-w-[210px] cursor-pointer hover:border-[#0071e3] focus:outline-none font-['SF_Pro_Display']"
            >
              {documents.map((doc) => (
                <option key={doc.id} value={doc.id}>
                  {doc.title}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Right Side: Mode Switcher, Upload, Settings */}
        <div className="flex items-center gap-3">
          
          {/* Explanation Mode Selector */}
          <div className="hidden sm:flex items-center bg-[#f5f5f7] rounded-[980px] p-1 text-[13px] font-['SF_Pro_Display']">
            {modes.map((m) => {
              const active = currentMode === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => onChangeMode(m.id)}
                  title={`${m.label} Mode: ${m.hint}`}
                  className={`px-3 py-1.5 rounded-[980px] font-medium flex items-center gap-1.5 transition-all ${
                    active
                      ? 'bg-white text-[#1d1d1f] shadow-xs font-semibold'
                      : 'text-[#86868b] hover:text-[#1d1d1f]'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${m.dotColor}`} />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>

          {/* Primary Action: Apple Button */}
          <button
            onClick={onOpenUpload}
            className="apple-btn-primary !min-h-[40px] !py-[8px] !px-[18px] !text-[15px]"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload</span>
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            title={hasApiKey ? 'Gemini AI Configured' : 'Configure Gemini API Key / Settings'}
            className="p-2.5 rounded-[980px] text-[#1d1d1f] hover:bg-[#f5f5f7] border border-[#e5e7eb] bg-white transition-colors relative"
          >
            <SlidersHorizontal className="w-4 h-4" />
            {hasApiKey ? (
              <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-white" />
            ) : (
              <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-[#0071e3] rounded-full border-2 border-white" />
            )}
          </button>

        </div>

      </div>
    </header>
  );
};
