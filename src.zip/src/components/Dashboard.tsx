import React, { useState, useMemo } from 'react';
import {
  FileText,
  UploadCloud,
  Search,
  Sparkles,
  AlertTriangle,
  BookOpen,
  Calendar,
  CheckCircle2,
  Trash2,
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import { DocumentRecord, DocumentCategory } from '../types/document';
import { CATEGORIES_CONFIG } from '../utils/categories';

interface DashboardProps {
  documents: DocumentRecord[];
  onSelectDocument: (doc: DocumentRecord) => void;
  onOpenUpload: () => void;
  onOpenSettings: () => void;
  onDeleteDocument: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  documents,
  onSelectDocument,
  onOpenUpload,
  onOpenSettings,
  onDeleteDocument
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<DocumentCategory | 'all'>('all');

  // Filter only real uploaded documents
  const filteredDocs = useMemo(() => {
    return documents.filter((doc) => {
      const matchesSearch =
        searchQuery === '' ||
        doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.category.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory =
        selectedCategory === 'all' || doc.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [documents, searchQuery, selectedCategory]);

  const categoriesList = Object.keys(CATEGORIES_CONFIG) as DocumentCategory[];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-8 py-10 space-y-10 bg-[#ffffff] font-['SF_Pro_Display']">
      
      {/* Clean Apple Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-[#e5e7eb] pb-8">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-[980px] bg-[#f5f5f7] text-[#0071e3] text-[13px] font-semibold">
            <FileText className="w-4 h-4 text-[#0071e3]" />
            <span>Document Understanding Assistant</span>
          </div>
          
          <h1 className="text-3xl sm:text-4xl font-bold text-[#1d1d1f] tracking-tight">
            Your Documents
          </h1>
          
          <p className="text-base text-[#86868b] max-w-xl">
            Upload any document to understand everything inside it. Plain explanations, extracted details, and full document navigation.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenUpload}
            className="apple-btn-primary"
          >
            <UploadCloud className="w-5 h-5" />
            <span>Upload Document</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {documents.length === 0 ? (
        /* Empty State: Focused Upload Area */
        <div className="apple-card p-12 sm:p-16 text-center space-y-6 border-dashed border-2 border-[#e5e7eb] rounded-[16px]">
          <div className="w-16 h-16 rounded-[16px] bg-[#f5f5f7] text-[#0071e3] flex items-center justify-center mx-auto">
            <UploadCloud className="w-8 h-8" />
          </div>

          <div className="space-y-2 max-w-md mx-auto">
            <h3 className="text-2xl font-bold text-[#1d1d1f]">
              No documents uploaded yet
            </h3>
            <p className="text-sm text-[#86868b] leading-relaxed">
              Upload your PDF, contract, admission slip, seat allotment, or receipt to get an instant, complete explanation of everything.
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={onOpenUpload}
              className="apple-btn-primary"
            >
              <UploadCloud className="w-5 h-5" />
              <span>Upload Document</span>
            </button>
          </div>
        </div>
      ) : (
        /* Real Uploaded Documents List */
        <div className="space-y-6">
          
          {/* Controls Bar: Search & Category Filter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-[#1d1d1f]">
                Uploaded Files ({documents.length})
              </span>
            </div>

            {/* Search */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-[#86868b] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search uploaded files..."
                className="w-full bg-[#f5f5f7] border border-transparent rounded-[8px] pl-10 pr-4 py-2 text-sm text-[#1d1d1f] placeholder-[#86868b] focus:outline-none focus:bg-white focus:border-[#0071e3] transition-all"
              />
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredDocs.map((doc) => {
              const meta = CATEGORIES_CONFIG[doc.category] || CATEGORIES_CONFIG.general;

              return (
                <div
                  key={doc.id}
                  onClick={() => onSelectDocument(doc)}
                  className="apple-card hover:border-[#0071e3] cursor-pointer flex flex-col justify-between group space-y-4 transition-all duration-200"
                >
                  <div className="space-y-3">
                    
                    {/* Top Row: Category & Ready Badge */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[12px] font-semibold px-2.5 py-0.5 rounded-[980px] bg-[#f5f5f7] text-[#1d1d1f]">
                        {meta.name}
                      </span>

                      <div className="flex items-center gap-2">
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-[980px]">
                          <CheckCircle2 className="w-3 h-3" />
                          Ready
                        </span>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`Delete "${doc.title}"?`)) {
                              onDeleteDocument(doc.id);
                            }
                          }}
                          title="Delete document"
                          className="p-1 text-[#86868b] hover:text-rose-600 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* File Title & Name */}
                    <div>
                      <h3 className="text-lg font-bold text-[#1d1d1f] group-hover:text-[#0071e3] transition-colors line-clamp-2 leading-snug">
                        {doc.title}
                      </h3>
                      <p className="text-[12px] text-[#86868b] mt-1 line-clamp-1 font-mono">
                        File: <span className="text-[#1d1d1f]">{doc.fileName}</span>
                      </p>
                    </div>

                    {/* Purpose / Summary from real file */}
                    <p className="text-[13px] text-[#86868b] line-clamp-3 leading-relaxed">
                      {doc.overview.keyTakeaway || doc.overview.executiveSummary || doc.overview.mainPurpose}
                    </p>
                  </div>

                  {/* File Metadata Row */}
                  <div className="pt-3 border-t border-[#e5e7eb] space-y-2">
                    <div className="flex items-center justify-between text-[12px] text-[#86868b]">
                      <span className="flex items-center gap-1.5">
                        <FileText className="w-4 h-4 text-[#0071e3]" />
                        {doc.pageCount} {doc.pageCount === 1 ? 'page' : 'pages'} • {doc.fileSize}
                      </span>

                      <span>
                        {new Date(doc.uploadedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                    </div>

                    <div className="flex items-center justify-end pt-1">
                      <span className="text-[14px] font-semibold text-[#0071e3] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                        Understand File <ChevronRight className="w-4 h-4" />
                      </span>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>

        </div>
      )}

    </div>
  );
};
