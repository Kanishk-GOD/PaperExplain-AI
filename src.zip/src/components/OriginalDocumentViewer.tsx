import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Sparkles,
  HelpCircle,
  Bookmark,
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { DocumentRecord } from '../types/document';

interface OriginalDocumentViewerProps {
  document: DocumentRecord;
  targetPage?: number;
  onPageChange?: (page: number) => void;
  onSelectExcerptForQuestion?: (text: string) => void;
  onSelectExcerptForExplain?: (text: string) => void;
}

export const OriginalDocumentViewer: React.FC<OriginalDocumentViewerProps> = ({
  document,
  targetPage = 1,
  onPageChange,
  onSelectExcerptForQuestion,
  onSelectExcerptForExplain
}) => {
  const [currentPage, setCurrentPage] = useState(targetPage);
  const [searchQuery, setSearchQuery] = useState('');
  const [zoomLevel, setZoomLevel] = useState(100);
  const [selectedText, setSelectedText] = useState('');
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(null);
  const [copied, setCopied] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (targetPage && targetPage !== currentPage) {
      setCurrentPage(targetPage);
    }
  }, [targetPage]);

  const handleMouseUp = () => {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) {
      setTooltipPos(null);
      setSelectedText('');
      return;
    }

    const text = selection.toString().trim();
    if (text.length > 5) {
      setSelectedText(text);
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      const containerRect = containerRef.current?.getBoundingClientRect();

      if (containerRect) {
        setTooltipPos({
          x: Math.max(10, rect.left - containerRect.left + rect.width / 2),
          y: Math.max(10, rect.top - containerRect.top - 45)
        });
      }
    } else {
      setTooltipPos(null);
      setSelectedText('');
    }
  };

  const textByPage = document?.originalContent?.textByPage || [];
  const totalPages = Math.max(1, textByPage.length || document?.pageCount || 1);
  const currentContent = textByPage[currentPage - 1] || document?.originalContent?.rawText || 'No text extracted for this page.';
  const isImageFile = Boolean(
    document?.originalContent?.imageBase64 ||
    document?.originalContent?.fileType?.startsWith('image/') ||
    (document?.fileName && /\.(jpe?g|png|webp|gif|bmp)$/i.test(document.fileName))
  );
  const imageSrc =
    document?.originalContent?.pdfUrl ||
    (document?.originalContent?.imageBase64
      ? `data:${document.originalContent.imageMimeType || 'image/jpeg'};base64,${document.originalContent.imageBase64}`
      : '');

  const renderHighlightedContent = (text: string) => {
    if (!searchQuery.trim()) return text;
    try {
      const parts = text.split(new RegExp(`(${searchQuery})`, 'gi'));
      return parts.map((part, i) =>
        part.toLowerCase() === searchQuery.toLowerCase() ? (
          <mark key={i} className="bg-[#BAE0FF] text-[#0071e3] rounded px-0.5 font-semibold">
            {part}
          </mark>
        ) : (
          part
        )
      );
    } catch {
      return text;
    }
  };

  const handleCopyPage = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      ref={containerRef}
      onMouseUp={handleMouseUp}
      className="relative flex flex-col h-full bg-[#f5f5f7] border border-[#e5e7eb] rounded-[8px] overflow-hidden select-text font-['SF_Pro_Display']"
    >
      {/* Viewer Header */}
      <div className="bg-white border-b border-[#e5e7eb] px-4 py-2.5 flex items-center justify-between gap-3 text-xs">
        
        {/* Page Nav */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              const prev = Math.max(1, currentPage - 1);
              setCurrentPage(prev);
              onPageChange?.(prev);
            }}
            disabled={currentPage <= 1}
            className="p-1.5 rounded-[980px] text-[#1d1d1f] hover:bg-[#f5f5f7] disabled:opacity-30 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <span className="font-semibold text-[#1d1d1f] min-w-[70px] text-center">
            Page {currentPage} of {totalPages}
          </span>

          <button
            onClick={() => {
              const next = Math.min(totalPages, currentPage + 1);
              setCurrentPage(next);
              onPageChange?.(next);
            }}
            disabled={currentPage >= totalPages}
            className="p-1.5 rounded-[980px] text-[#1d1d1f] hover:bg-[#f5f5f7] disabled:opacity-30 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Search Input */}
        <div className="relative flex-1 max-w-[200px] hidden sm:block">
          <Search className="w-3.5 h-3.5 text-[#86868b] absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search page..."
            className="w-full bg-[#f5f5f7] border border-transparent rounded-[8px] pl-7 pr-3 py-1 text-[11px] placeholder-[#86868b] focus:outline-none focus:bg-white focus:border-[#0071e3]"
          />
        </div>

        {/* Zoom & Copy */}
        <div className="flex items-center gap-1 text-[#1d1d1f]">
          <button
            onClick={() => setZoomLevel((z) => Math.max(80, z - 10))}
            className="p-1.5 rounded-[980px] hover:bg-[#f5f5f7] transition-colors"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="text-[11px] font-mono font-medium text-[#86868b] w-9 text-center">
            {zoomLevel}%
          </span>
          <button
            onClick={() => setZoomLevel((z) => Math.min(140, z + 10))}
            className="p-1.5 rounded-[980px] hover:bg-[#f5f5f7] transition-colors"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-px bg-[#e5e7eb] mx-1" />

          <button
            onClick={handleCopyPage}
            className="p-1.5 rounded-[980px] hover:bg-[#f5f5f7] transition-colors flex items-center gap-1 text-[11px] text-[#86868b]"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

      </div>

      {/* Floating Action Tooltip */}
      {tooltipPos && selectedText && (
        <div
          style={{
            position: 'absolute',
            left: `${tooltipPos.x}px`,
            top: `${tooltipPos.y}px`,
            transform: 'translateX(-50%)',
            zIndex: 40
          }}
          className="bg-[#1d1d1f] text-white rounded-[980px] px-3.5 py-1.5 flex items-center gap-2.5 text-xs font-semibold shadow-xl"
        >
          <button
            onClick={() => {
              onSelectExcerptForExplain?.(selectedText);
              setTooltipPos(null);
            }}
            className="flex items-center gap-1 hover:text-[#2997ff] transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#2997ff]" />
            <span>Explain Selection</span>
          </button>
          <span className="text-zinc-600">|</span>
          <button
            onClick={() => {
              onSelectExcerptForQuestion?.(selectedText);
              setTooltipPos(null);
            }}
            className="flex items-center gap-1 hover:text-[#2997ff] transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-300" />
            <span>Ask AI</span>
          </button>
        </div>
      )}

      {/* Document Canvas */}
      <div className="flex-1 overflow-auto p-4 sm:p-6 flex justify-center">
        <div
          style={{ fontSize: `${(zoomLevel / 100) * 14}px` }}
          className="bg-white border border-[#e5e7eb] rounded-[8px] p-8 sm:p-10 max-w-2xl w-full min-h-[550px] leading-relaxed text-[#1d1d1f] transition-all font-['SF_Pro_Display']"
        >
          <div className="border-b border-[#e5e7eb] pb-3 mb-6 flex items-center justify-between text-[11px] text-[#86868b] font-medium">
            <span>{document.fileName}</span>
            <span>{isImageFile ? 'Document Image' : `Page ${currentPage} of ${totalPages}`}</span>
          </div>

          {isImageFile && imageSrc ? (
            <div className="flex flex-col items-center justify-center p-2 bg-[#f5f5f7] rounded-[8px] border border-[#e5e7eb] overflow-hidden">
              <img
                src={imageSrc}
                alt={document.fileName}
                style={{
                  transform: `scale(${zoomLevel / 100})`,
                  transformOrigin: 'top center'
                }}
                className="max-h-[580px] w-auto object-contain rounded-[6px] shadow-sm transition-transform select-none"
              />
            </div>
          ) : (
            <div className="whitespace-pre-wrap text-[#1d1d1f] select-text">
              {renderHighlightedContent(currentContent)}
            </div>
          )}

          <div className="border-t border-[#e5e7eb] pt-4 mt-8 flex items-center justify-between text-[10px] text-[#86868b]">
            <span>PaperExplain AI • Original Document Preview</span>
            <span>Ref: {document.id}</span>
          </div>
        </div>
      </div>

      {/* Bottom Page Thumbnails */}
      {totalPages > 1 && (
        <div className="bg-white border-t border-[#e5e7eb] px-3 py-2 flex items-center gap-2 overflow-x-auto text-[12px]">
          <span className="text-[#86868b] font-medium whitespace-nowrap">Pages:</span>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <button
              key={p}
              onClick={() => {
                setCurrentPage(p);
                onPageChange?.(p);
              }}
              className={`px-3 py-0.5 rounded-[980px] font-semibold transition-all ${
                currentPage === p
                  ? 'bg-[#0071e3] text-white'
                  : 'bg-[#f5f5f7] text-[#1d1d1f] hover:bg-[#e8e8ed]'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      )}

    </div>
  );
};
