import React, { useState, useRef, useEffect } from 'react';
import {
  FileText,
  BookOpen,
  AlertTriangle,
  HelpCircle,
  Sparkles,
  ListOrdered,
  Calendar,
  DollarSign,
  Shield,
  Layers,
  ChevronDown,
  ChevronUp,
  Volume2,
  VolumeX,
  Send,
  ArrowRight,
  Maximize2,
  Minimize2,
  Download,
  Info,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Search,
  Scale,
  Briefcase,
  HeartHandshake,
  Languages,
  RotateCcw
} from 'lucide-react';
import {
  DocumentRecord,
  ExplanationMode,
  ExplanationLanguage,
  DocumentSection,
  TerminologyItem,
  RiskAndWarning,
  QAPair
} from '../types/document';
import { OriginalDocumentViewer } from './OriginalDocumentViewer';
import { askDocumentAssistant } from '../services/geminiService';
import { CATEGORIES_CONFIG } from '../utils/categories';
import {
  SUPPORTED_LANGUAGES,
  translateDocumentRecord,
  getSampleQuestionsForLanguage,
  translationCache
} from '../services/multilingualService';

interface AnalysisInterfaceProps {
  document: DocumentRecord;
  currentMode: ExplanationMode;
  onChangeMode: (mode: ExplanationMode) => void;
  onUpdateDocument: (updated: DocumentRecord) => void;
  geminiApiKey?: string;
  geminiModel?: string;
}

export type AnalysisTab =
  | 'overview'
  | 'sections'
  | 'details'
  | 'terminology'
  | 'risks'
  | 'chat';

export const AnalysisInterface: React.FC<AnalysisInterfaceProps> = ({
  document,
  currentMode,
  onChangeMode,
  onUpdateDocument,
  geminiApiKey,
  geminiModel
}) => {
  const [activeTab, setActiveTab] = useState<AnalysisTab>('overview');
  const [targetViewerPage, setTargetViewerPage] = useState<number>(1);
  
  // Layout states: Default is 'stacked' (Document Context on Top, Fullscreen Explanation Below)
  const [layoutMode, setLayoutMode] = useState<'stacked' | 'split-50' | 'full-explanation'>('stacked');
  const [isFullscreenModal, setIsFullscreenModal] = useState<boolean>(false);
  const [isContextCollapsed, setIsContextCollapsed] = useState<boolean>(false);

  // Language state: English, Hindi (हिंदी), Marathi (मराठी)
  const [currentLanguage, setCurrentLanguage] = useState<ExplanationLanguage>(
    document.currentLanguage || 'en'
  );
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [displayDoc, setDisplayDoc] = useState<DocumentRecord>(document);

  // Search inside sections/terminology
  const [sectionSearch, setSectionSearch] = useState('');
  const [termSearch, setTermSearch] = useState('');
  const [expandedSectionId, setExpandedSectionId] = useState<string | null>(document.sections[0]?.id || null);

  // Chat State
  const [chatQuestion, setChatQuestion] = useState('');
  const [isAsking, setIsAsking] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Text-To-Speech (Web Speech API)
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  // Synchronize when document changes
  useEffect(() => {
    if (document.currentLanguage && document.currentLanguage !== currentLanguage) {
      setCurrentLanguage(document.currentLanguage);
    }
    setDisplayDoc(document);
  }, [document.id]);

  const handleLanguageSwitch = async (lang: ExplanationLanguage) => {
    setCurrentLanguage(lang);
    if (lang === 'en') {
      const baseEnglishDoc = (translationCache[`${document.id}_en`] as DocumentRecord) || document;
      const enDoc: DocumentRecord = { ...baseEnglishDoc, currentLanguage: 'en' };
      setDisplayDoc(enDoc);
      onUpdateDocument(enDoc);
      return;
    }

    setIsTranslating(true);
    try {
      // Ensure English original is saved in cache first
      if (!translationCache[`${document.id}_en`]) {
        translationCache[`${document.id}_en`] = document;
      }
      const baseEnglishDoc = (translationCache[`${document.id}_en`] as DocumentRecord) || document;
      const translated = await translateDocumentRecord(
        baseEnglishDoc,
        lang,
        geminiApiKey,
        geminiModel
      );
      setDisplayDoc(translated);
      onUpdateDocument(translated);
    } catch (e) {
      console.warn('Language switch error:', e);
    } finally {
      setIsTranslating(false);
    }
  };

  const stopSpeaking = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
    }
  };

  const speakText = (id: string, text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (speakingId === id) {
      stopSpeaking();
      return;
    }
    stopSpeaking();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    // Speech language selection
    if (currentLanguage === 'mr') {
      utterance.lang = 'mr-IN';
    } else if (currentLanguage === 'hi') {
      utterance.lang = 'hi-IN';
    } else {
      utterance.lang = 'en-US';
    }

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    window.speechSynthesis.speak(utterance);
    setSpeakingId(id);
  };

  useEffect(() => {
    return () => {
      stopSpeaking();
    };
  }, []);

  // Jump to specific page in original document preview
  const handleJumpToPage = (page: number) => {
    setTargetViewerPage(page);
    if (isContextCollapsed) {
      setIsContextCollapsed(false);
    }
  };

  // Submit AI Question
  const handleAskQuestion = async (customQ?: string) => {
    const q = (customQ || chatQuestion).trim();
    if (!q || isAsking) return;

    setChatQuestion('');
    setIsAsking(true);
    setActiveTab('chat');

    try {
      const response = await askDocumentAssistant(
        displayDoc,
        q,
        geminiApiKey,
        geminiModel,
        currentMode,
        currentLanguage
      );

      const newQA: QAPair = {
        id: 'qa-' + Date.now(),
        question: q,
        answer: response.answer,
        pageReferences: response.pageReferences,
        sectionReferences: response.sectionReferences,
        timestamp: new Date().toISOString(),
        explanationMode: currentMode
      };

      const updatedHistory = [...(displayDoc.chatHistory || []), newQA];
      const updatedDoc: DocumentRecord = {
        ...displayDoc,
        chatHistory: updatedHistory
      };
      setDisplayDoc(updatedDoc);
      onUpdateDocument(updatedDoc);

      setTimeout(() => {
        chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err) {
      console.error('Ask AI error:', err);
    } finally {
      setIsAsking(false);
    }
  };

  const categoryMeta = CATEGORIES_CONFIG[document.category] || CATEGORIES_CONFIG.general;
  const samplePrompts = getSampleQuestionsForLanguage(currentLanguage);

  const handleExportMarkdown = () => {
    const md = `# PaperExplain AI Analysis: ${displayDoc.title}
**Language:** ${currentLanguage.toUpperCase()} | **Category:** ${displayDoc.category.toUpperCase()} | **Date:** ${new Date(displayDoc.uploadedAt).toLocaleDateString()}
**Issuer:** ${displayDoc.overview.issuer}
**Intended For:** ${displayDoc.overview.intendedAudience}

---

## 1. Overview & Purpose
${displayDoc.overview.executiveSummary}

**Main Purpose:**
${displayDoc.overview.mainPurpose}

**Key Takeaway:**
${displayDoc.overview.keyTakeaway}

---

## 2. Section-by-Section Explanations
${displayDoc.sections
  .map(
    (s) => `### ${s.sectionNumber}: ${s.originalHeading} (Page ${s.pageNumber})
**Original Text:** ${s.originalText.slice(0, 300)}...

**Explanation (${currentMode.toUpperCase()}):**
${
  currentMode === 'simple'
    ? s.simpleExplanation
    : currentMode === 'beginner'
    ? s.beginnerExplanation
    : currentMode === 'professional'
    ? s.professionalExplanation
    : s.detailedExplanation
}

**Why It Matters:** ${s.whyImportant}
**What It Means For You:** ${s.whatItMeansForYou}
**Critical Info:** ${s.criticalOverlookedInfo}
`
  )
  .join('\n')}

---
*Report generated by PaperExplain AI. Automated analysis does not constitute formal legal, financial, or medical advice.*`;

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${displayDoc.title.replace(/\s+/g, '_')}_PaperExplain_${currentLanguage}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`max-w-[1600px] mx-auto px-4 sm:px-8 py-6 space-y-6 bg-[#ffffff] font-['SF_Pro_Display'] ${isFullscreenModal ? 'fixed inset-0 z-50 bg-white p-6 sm:p-10 overflow-y-auto max-w-none' : ''}`}>
      
      {/* Top Document Header Bar: Apple Card */}
      <div className="apple-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5 max-w-3xl">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[12px] font-semibold px-2.5 py-0.5 rounded-[980px] bg-[#f5f5f7] text-[#1d1d1f]">
              {categoryMeta.name}
            </span>
            <span className="text-xs text-[#86868b] font-medium">
              {document.pageCount} {document.pageCount === 1 ? 'Page' : 'Pages'} • {document.fileSize}
            </span>
            <span className="text-zinc-300">•</span>
            <span className="text-xs text-[#86868b] font-medium">
              ~{document.overview.estimatedReadingTimeMinutes} min est. reading time
            </span>
            {isTranslating && (
              <span className="text-xs font-semibold text-[#0071e3] bg-blue-50 px-2.5 py-0.5 rounded-[980px] animate-pulse flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 animate-spin" />
                Translating to {SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage)?.nativeName}...
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#1d1d1f] tracking-tight">
            {displayDoc.title}
          </h1>
          <p className="text-xs text-[#86868b] line-clamp-1">
            <span className="font-semibold text-[#1d1d1f]">Issued By:</span> {displayDoc.overview.issuer} • <span className="font-semibold text-[#1d1d1f]">Intended For:</span> {displayDoc.overview.intendedAudience}
          </p>
        </div>

        {/* Controls: Language Selector, Layout Toggles & Export */}
        <div className="flex items-center gap-2.5 flex-wrap self-start md:self-center">
          
          {/* Language Selector Pill: English, Hindi, Marathi */}
          <div className="flex items-center bg-[#f5f5f7] p-1 rounded-[980px] text-[12px] font-medium text-[#86868b]">
            <div className="px-2 text-[#1d1d1f] flex items-center gap-1 font-semibold">
              <Languages className="w-3.5 h-3.5 text-[#0071e3]" />
              <span className="hidden sm:inline">Language:</span>
            </div>
            {SUPPORTED_LANGUAGES.map((lang) => (
              <button
                key={lang.code}
                onClick={() => handleLanguageSwitch(lang.code)}
                disabled={isTranslating}
                className={`px-3 py-1 rounded-[980px] transition-all flex items-center gap-1.5 ${
                  currentLanguage === lang.code
                    ? 'bg-[#0071e3] text-white font-semibold shadow-xs'
                    : 'hover:text-[#1d1d1f]'
                }`}
              >
                <span>{lang.flag}</span>
                <span>{lang.nativeName}</span>
              </button>
            ))}
          </div>

          {/* Layout Mode Toggles */}
          <div className="hidden lg:flex items-center bg-[#f5f5f7] p-1 rounded-[980px] text-[12px] font-medium text-[#86868b]">
            <button
              onClick={() => setLayoutMode('stacked')}
              className={`px-3 py-1 rounded-[980px] transition-all ${
                layoutMode === 'stacked'
                  ? 'bg-white text-[#1d1d1f] font-semibold shadow-xs'
                  : 'hover:text-[#1d1d1f]'
              }`}
            >
              Stacked (Default)
            </button>
            <button
              onClick={() => setLayoutMode('split-50')}
              className={`px-3 py-1 rounded-[980px] transition-all ${
                layoutMode === 'split-50'
                  ? 'bg-white text-[#1d1d1f] font-semibold shadow-xs'
                  : 'hover:text-[#1d1d1f]'
              }`}
            >
              Split View
            </button>
          </div>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => setIsFullscreenModal(!isFullscreenModal)}
            title={isFullscreenModal ? 'Exit Fullscreen' : 'Fullscreen View'}
            className="apple-btn-secondary !min-h-[38px] !py-[6px] !px-[14px] !text-[13px] flex items-center gap-1.5"
          >
            {isFullscreenModal ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            <span className="hidden sm:inline">{isFullscreenModal ? 'Exit Fullscreen' : 'Fullscreen'}</span>
          </button>

          <button
            onClick={handleExportMarkdown}
            className="apple-btn-secondary !min-h-[38px] !py-[6px] !px-[14px] !text-[13px]"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </div>

      {/* =========================================================================
          STACKED LAYOUT: CONTEXT ON TOP, FULLSCREEN EXPLANATION BELOW
          ========================================================================= */}
      {layoutMode === 'stacked' ? (
        <div className="space-y-6">
          
          {/* Top Section: Original Document Context Preview */}
          <div className="apple-card space-y-3">
            <div className="flex items-center justify-between border-b border-[#e5e7eb] pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#0071e3]" />
                <h3 className="text-sm font-bold text-[#1d1d1f]">
                  Document Context & Original Content
                </h3>
                <span className="text-xs text-[#86868b]">
                  ({document.fileName} • {document.pageCount} {document.pageCount === 1 ? 'Page' : 'Pages'})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsContextCollapsed(!isContextCollapsed)}
                  className="text-xs font-semibold text-[#0071e3] hover:underline flex items-center gap-1"
                >
                  {isContextCollapsed ? (
                    <>
                      <span>Expand Context View</span>
                      <ChevronDown className="w-4 h-4" />
                    </>
                  ) : (
                    <>
                      <span>Collapse Context</span>
                      <ChevronUp className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>

            {!isContextCollapsed && (
              <div className="h-[360px] sm:h-[420px] transition-all">
                <OriginalDocumentViewer
                  document={document}
                  targetPage={targetViewerPage}
                  onPageChange={(p) => setTargetViewerPage(p)}
                  onSelectExcerptForQuestion={(text) => {
                    setChatQuestion(`Explain this excerpt from the document: "${text}"`);
                    setActiveTab('chat');
                  }}
                  onSelectExcerptForExplain={(text) => {
                    handleAskQuestion(`Please explain this specific passage in ${currentMode} mode: "${text}"`);
                  }}
                />
              </div>
            )}
          </div>

          {/* Bottom Section: Fullscreen / Full-Width Explanation Workspace */}
          <div className="space-y-4">
            
            {/* Tabs Navigation Bar: Apple Segmented Pill */}
            <div className="flex items-center justify-between border-b border-[#e5e7eb] pb-3 overflow-x-auto scrollbar-none gap-4">
              <div className="flex items-center gap-1.5 text-[13px] font-medium bg-[#f5f5f7] p-1 rounded-[980px]">
                
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`px-4 py-1.5 rounded-[980px] flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    activeTab === 'overview'
                      ? 'bg-[#0071e3] text-white font-semibold shadow-xs'
                      : 'text-[#1d1d1f] hover:text-[#0071e3]'
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>1. Overview</span>
                </button>

                <button
                  onClick={() => setActiveTab('sections')}
                  className={`px-4 py-1.5 rounded-[980px] flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    activeTab === 'sections'
                      ? 'bg-[#0071e3] text-white font-semibold shadow-xs'
                      : 'text-[#1d1d1f] hover:text-[#0071e3]'
                  }`}
                >
                  <ListOrdered className="w-3.5 h-3.5" />
                  <span>2. Section Breakdown</span>
                  <span className="text-[11px] px-1.5 py-0.2 rounded-full bg-white/20">
                    {(displayDoc.sections || []).length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('details')}
                  className={`px-4 py-1.5 rounded-[980px] flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    activeTab === 'details'
                      ? 'bg-[#0071e3] text-white font-semibold shadow-xs'
                      : 'text-[#1d1d1f] hover:text-[#0071e3]'
                  }`}
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>3. Important Details</span>
                </button>

                <button
                  onClick={() => setActiveTab('terminology')}
                  className={`px-4 py-1.5 rounded-[980px] flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    activeTab === 'terminology'
                      ? 'bg-[#0071e3] text-white font-semibold shadow-xs'
                      : 'text-[#1d1d1f] hover:text-[#0071e3]'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>4. Key Terminology</span>
                  <span className="text-[11px] px-1.5 py-0.2 rounded-full bg-white/20">
                    {(displayDoc.terminology || []).length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('risks')}
                  className={`px-4 py-1.5 rounded-[980px] flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    activeTab === 'risks'
                      ? 'bg-rose-600 text-white font-semibold shadow-xs'
                      : 'text-rose-700 hover:text-rose-800'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>5. Risks & Warnings</span>
                  {(displayDoc.risks || []).length > 0 && (
                    <span className="text-[11px] px-1.5 py-0.2 rounded-full bg-white/30 font-bold">
                      {(displayDoc.risks || []).length}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('chat')}
                  className={`px-4 py-1.5 rounded-[980px] flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    activeTab === 'chat'
                      ? 'bg-[#0071e3] text-white font-semibold shadow-xs'
                      : 'text-[#0071e3] hover:underline'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-white" />
                  <span>6. Ask AI Assistant</span>
                </button>

              </div>

              {/* Mode indicator */}
              <div className="flex items-center gap-2 text-xs text-[#86868b] font-medium shrink-0">
                <span>Mode:</span>
                <div className="flex items-center gap-1 bg-[#f5f5f7] p-0.5 rounded-[980px]">
                  {(['simple', 'detailed', 'professional', 'beginner'] as ExplanationMode[]).map((m) => (
                    <button
                      key={m}
                      onClick={() => onChangeMode(m)}
                      className={`px-2.5 py-0.5 rounded-[980px] capitalize text-[11px] font-semibold transition-all ${
                        currentMode === m
                          ? 'bg-white text-[#0071e3] shadow-xs'
                          : 'text-[#86868b] hover:text-[#1d1d1f]'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Explanation Content: Full-width container */}
            <div className="apple-card p-6 sm:p-8 space-y-6">
              {renderTabContent()}
            </div>

          </div>

        </div>
      ) : (
        /* =========================================================================
           SPLIT-SCREEN VIEW (OPTIONAL ALTERNATIVE)
           ========================================================================= */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[720px] items-stretch">
          
          <div className="lg:col-span-5">
            <OriginalDocumentViewer
              document={document}
              targetPage={targetViewerPage}
              onPageChange={(p) => setTargetViewerPage(p)}
              onSelectExcerptForQuestion={(text) => {
                setChatQuestion(`Explain this excerpt from the document: "${text}"`);
                setActiveTab('chat');
              }}
              onSelectExcerptForExplain={(text) => {
                handleAskQuestion(`Please explain this specific passage in ${currentMode} mode: "${text}"`);
              }}
            />
          </div>

          <div className="lg:col-span-7">
            <div className="apple-card flex flex-col h-[750px] overflow-hidden p-0">
              
              <div className="border-b border-[#e5e7eb] px-4 py-2.5 flex items-center justify-between gap-2 overflow-x-auto">
                <div className="flex items-center gap-1 text-xs">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`px-3 py-1 rounded-[980px] font-semibold ${
                      activeTab === 'overview' ? 'bg-[#0071e3] text-white' : 'text-[#86868b]'
                    }`}
                  >
                    Overview
                  </button>
                  <button
                    onClick={() => setActiveTab('sections')}
                    className={`px-3 py-1 rounded-[980px] font-semibold ${
                      activeTab === 'sections' ? 'bg-[#0071e3] text-white' : 'text-[#86868b]'
                    }`}
                  >
                    Sections
                  </button>
                  <button
                    onClick={() => setActiveTab('details')}
                    className={`px-3 py-1 rounded-[980px] font-semibold ${
                      activeTab === 'details' ? 'bg-[#0071e3] text-white' : 'text-[#86868b]'
                    }`}
                  >
                    Details
                  </button>
                  <button
                    onClick={() => setActiveTab('terminology')}
                    className={`px-3 py-1 rounded-[980px] font-semibold ${
                      activeTab === 'terminology' ? 'bg-[#0071e3] text-white' : 'text-[#86868b]'
                    }`}
                  >
                    Glossary
                  </button>
                  <button
                    onClick={() => setActiveTab('risks')}
                    className={`px-3 py-1 rounded-[980px] font-semibold ${
                      activeTab === 'risks' ? 'bg-rose-600 text-white' : 'text-rose-700'
                    }`}
                  >
                    Risks
                  </button>
                  <button
                    onClick={() => setActiveTab('chat')}
                    className={`px-3 py-1 rounded-[980px] font-semibold ${
                      activeTab === 'chat' ? 'bg-[#0071e3] text-white' : 'text-[#0071e3]'
                    }`}
                  >
                    Ask AI
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {renderTabContent()}
              </div>

            </div>
          </div>

        </div>
      )}

    </div>
  );

  /**
   * Main Tab Content Renderer: Shared cleanly across both Stacked and Split layouts
   */
  function renderTabContent() {
    return (
      <>
        {/* ----------------- TAB 1: OVERVIEW ----------------- */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            <div className="p-6 sm:p-8 rounded-[12px] bg-[#f5f5f7] border border-[#e5e7eb] space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[#0071e3] text-xs font-bold uppercase tracking-wider">
                  <Sparkles className="w-4 h-4" />
                  <span>Complete Document Understanding & Explanation</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => speakText('overview-summary', displayDoc.overview.executiveSummary)}
                    className="p-1.5 rounded-[980px] border border-[#e5e7eb] bg-white text-[#1d1d1f] hover:bg-[#f5f5f7] text-xs flex items-center gap-1"
                  >
                    {speakingId === 'overview-summary' ? <VolumeX className="w-3.5 h-3.5 text-rose-600" /> : <Volume2 className="w-3.5 h-3.5 text-[#0071e3]" />}
                    <span className="text-[11px] font-semibold">{speakingId === 'overview-summary' ? 'Stop' : 'Read Aloud'}</span>
                  </button>
                </div>
              </div>
              
              <h2 className="text-2xl sm:text-3xl font-bold text-[#1d1d1f] tracking-tight">
                What Is This Document About?
              </h2>

              <p className="text-base text-[#1d1d1f] leading-relaxed">
                {displayDoc.overview.executiveSummary}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
                <div className="apple-card space-y-1">
                  <span className="text-[11px] font-bold uppercase text-[#86868b]">Document Type</span>
                  <p className="text-xs font-semibold text-[#1d1d1f]">{displayDoc.overview.documentType}</p>
                </div>
                <div className="apple-card space-y-1">
                  <span className="text-[11px] font-bold uppercase text-[#86868b]">Originating Authority</span>
                  <p className="text-xs font-semibold text-[#1d1d1f]">{displayDoc.overview.issuer}</p>
                </div>
                <div className="apple-card space-y-1">
                  <span className="text-[11px] font-bold uppercase text-[#86868b]">Intended Recipient</span>
                  <p className="text-xs font-semibold text-[#1d1d1f]">{displayDoc.overview.intendedAudience}</p>
                </div>
                <div className="apple-card space-y-1">
                  <span className="text-[11px] font-bold uppercase text-[#86868b]">Subject</span>
                  <p className="text-xs font-semibold text-[#1d1d1f] line-clamp-2">{displayDoc.overview.overallSubject}</p>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <div className="p-4 rounded-[8px] bg-white border border-[#e5e7eb] space-y-1.5">
                  <span className="text-xs font-bold text-[#0071e3] flex items-center gap-1.5">
                    <Info className="w-4 h-4 text-[#0071e3]" />
                    Main Purpose & Why It Was Created
                  </span>
                  <p className="text-sm text-[#1d1d1f] leading-relaxed">
                    {displayDoc.overview.mainPurpose}
                  </p>
                </div>

                <div className="p-4 rounded-[8px] bg-emerald-50/70 border border-emerald-200 space-y-1.5">
                  <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                    Core Takeaway & What You Must Understand
                  </span>
                  <p className="text-sm text-emerald-950 font-medium leading-relaxed">
                    {displayDoc.overview.keyTakeaway}
                  </p>
                </div>
              </div>
            </div>

            {/* Overall Practical Implications */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-[#1d1d1f] flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-[#0071e3]" />
                Practical Implications: What This Means In Practice
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="apple-card space-y-2">
                  <span className="text-xs font-bold text-[#1d1d1f] flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#0071e3]" />
                    What does this document require me to do?
                  </span>
                  <ul className="space-y-1.5 text-xs text-[#86868b]">
                    {(displayDoc.implications?.requiresMeToDo || []).map((item, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-[#0071e3] font-bold">•</span>
                        <span className="text-[#1d1d1f]">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="apple-card space-y-2">
                  <span className="text-xs font-bold text-[#1d1d1f] flex items-center gap-1.5">
                    <HeartHandshake className="w-4 h-4 text-[#0071e3]" />
                    What am I agreeing to?
                  </span>
                  <ul className="space-y-1.5 text-xs text-[#86868b]">
                    {(displayDoc.implications?.whatAmIAgreeingTo || []).map((item, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-[#0071e3] font-bold">•</span>
                        <span className="text-[#1d1d1f]">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="apple-card space-y-2">
                  <span className="text-xs font-bold text-[#1d1d1f] flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-emerald-600" />
                    What rights do I receive?
                  </span>
                  <ul className="space-y-1.5 text-xs text-[#86868b]">
                    {(displayDoc.implications?.rightsReceived || []).map((item, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-emerald-500 font-bold">•</span>
                        <span className="text-[#1d1d1f]">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="apple-card space-y-2 bg-rose-50/40 border-rose-200">
                  <span className="text-xs font-bold text-rose-900 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    What happens if I do not follow conditions?
                  </span>
                  <ul className="space-y-1.5 text-xs text-rose-950">
                    {(displayDoc.implications?.consequencesOfNonCompliance || []).map((item, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-rose-500 font-bold">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="apple-card bg-[#1d1d1f] text-white space-y-2">
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  Critical Things You Should Never Forget
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-zinc-200">
                  {(displayDoc.implications?.criticalThingsToRemember || []).map((item, i) => (
                    <div key={i} className="flex items-start gap-2 bg-white/10 p-2.5 rounded-[6px]">
                      <span className="text-amber-400 font-bold">{i + 1}.</span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        )}

        {/* ----------------- TAB 2: FULL EXPLANATION ----------------- */}
        {activeTab === 'sections' && (
          <div className="space-y-6">
            
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#f5f5f7] p-4 rounded-[8px]">
              <div>
                <h3 className="text-base font-bold text-[#1d1d1f]">
                  Detailed Section-by-Section Explanation
                </h3>
                <p className="text-xs text-[#86868b]">
                  {`Explanation Language: ${SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage)?.nativeName} • Mode: ${currentMode}`}
                </p>
              </div>

              {/* Quick Table of Contents Filter */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                <span className="text-[#86868b] font-medium whitespace-nowrap text-[12px]">Jump:</span>
                {(displayDoc.sections || []).map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      setExpandedSectionId(s.id);
                      handleJumpToPage(s.pageNumber);
                    }}
                    className={`px-3 py-1 rounded-[980px] whitespace-nowrap border text-[12px] font-medium transition-all ${
                      expandedSectionId === s.id
                        ? 'bg-[#0071e3] border-[#0071e3] text-white font-semibold'
                        : 'bg-white border-[#e5e7eb] text-[#1d1d1f] hover:border-[#0071e3]'
                    }`}
                  >
                    {s.sectionNumber} (P.{s.pageNumber})
                  </button>
                ))}
              </div>
            </div>

            {/* Section Cards */}
            <div className="space-y-4">
              {(displayDoc.sections || []).map((sec, idx) => {
                const isExpanded = expandedSectionId === sec.id;
                
                const modeExplanation =
                  currentMode === 'simple'
                    ? sec.simpleExplanation
                    : currentMode === 'beginner'
                    ? sec.beginnerExplanation
                    : currentMode === 'professional'
                    ? sec.professionalExplanation
                    : sec.detailedExplanation;

                const speechKey = `sec-${sec.id}`;
                const isSpeaking = speakingId === speechKey;

                return (
                  <div
                    key={sec.id}
                    className={`apple-card transition-all ${
                      isExpanded ? 'border-[#0071e3] ring-1 ring-[#0071e3]/20' : 'hover:border-[#0071e3]'
                    }`}
                  >
                    <div
                      onClick={() => {
                        setExpandedSectionId(isExpanded ? null : sec.id);
                        handleJumpToPage(sec.pageNumber);
                      }}
                      className="flex items-center justify-between gap-3 cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-[8px] bg-[#f5f5f7] text-xs font-bold text-[#1d1d1f] flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[12px] font-semibold text-[#0071e3]">
                              {sec.sectionNumber}
                            </span>
                            <span
                              onClick={(e) => {
                                e.stopPropagation();
                                handleJumpToPage(sec.pageNumber);
                              }}
                              className="text-[11px] px-2 py-0.5 rounded-[980px] bg-[#f5f5f7] text-[#86868b] hover:text-[#1d1d1f]"
                            >
                              Page {sec.pageNumber}
                            </span>
                          </div>
                          <h4 className="text-base font-bold text-[#1d1d1f]">
                            {sec.originalHeading}
                          </h4>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            speakText(speechKey, modeExplanation);
                          }}
                          className={`p-2 rounded-[980px] border text-xs transition-colors ${
                            isSpeaking
                              ? 'bg-[#0071e3] text-white border-[#0071e3] animate-pulse'
                              : 'bg-white text-[#86868b] hover:text-[#1d1d1f] border-[#e5e7eb]'
                          }`}
                        >
                          {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </button>
                        {isExpanded ? <ChevronUp className="w-4 h-4 text-[#86868b]" /> : <ChevronDown className="w-4 h-4 text-[#86868b]" />}
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="mt-4 pt-4 border-t border-[#e5e7eb] space-y-4">
                        <div className="bg-[#f5f5f7] rounded-[8px] p-4 text-xs text-[#1d1d1f] leading-relaxed">
                          <div className="text-[11px] uppercase font-bold text-[#86868b] mb-1 flex items-center justify-between">
                            <span>Original Document Text</span>
                            <button
                              onClick={() => handleJumpToPage(sec.pageNumber)}
                              className="text-[#0071e3] hover:underline flex items-center gap-1"
                            >
                              View Page {sec.pageNumber} <ExternalLink className="w-3 h-3" />
                            </button>
                          </div>
                          <p className="italic">"{sec.originalText}"</p>
                        </div>

                        <div className="space-y-1">
                          <span className="text-xs font-bold text-[#0071e3] flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5" />
                            Explanation ({currentMode.toUpperCase()} Mode)
                          </span>
                          <p className="text-sm text-[#1d1d1f] leading-relaxed bg-blue-50/40 p-4 rounded-[8px] border border-blue-100 font-medium">
                            {modeExplanation}
                          </p>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div className="p-3.5 rounded-[8px] bg-[#f5f5f7] space-y-1">
                            <span className="font-bold text-[#1d1d1f]">
                              Why this is important:
                            </span>
                            <p className="text-[#86868b] leading-relaxed">{sec.whyImportant}</p>
                          </div>

                          <div className="p-3.5 rounded-[8px] bg-[#f5f5f7] space-y-1">
                            <span className="font-bold text-[#1d1d1f]">
                              What it means for the reader:
                            </span>
                            <p className="text-[#86868b] leading-relaxed">{sec.whatItMeansForYou}</p>
                          </div>
                        </div>

                        <div className="p-3.5 rounded-[8px] bg-amber-50 border border-amber-200 text-xs space-y-1">
                          <span className="font-bold text-amber-900 flex items-center gap-1.5">
                            <AlertCircle className="w-4 h-4 text-amber-700" />
                            Critical Overlooked Details:
                          </span>
                          <p className="text-amber-950 leading-relaxed">{sec.criticalOverlookedInfo}</p>
                        </div>
                      </div>
                    )}

                  </div>
                );
              })}
            </div>

          </div>
        )}

        {/* ----------------- TAB 3: IMPORTANT DETAILS ----------------- */}
        {activeTab === 'details' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold text-[#1d1d1f]">
                Structured Information Extraction
              </h3>
              <p className="text-xs text-[#86868b]">
                Extracted dates, financial figures, commitments, and rights.
              </p>
            </div>

            {/* References and IDs */}
            {displayDoc.extractedInfo.referencesAndIds && displayDoc.extractedInfo.referencesAndIds.length > 0 && (
              <div className="apple-card space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#86868b] flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-[#0071e3]" />
                  Document Identifiers & Reference Numbers
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 text-xs">
                  {(displayDoc.extractedInfo?.referencesAndIds || []).map((item, idx) => (
                    <div key={idx} className="p-3.5 rounded-[8px] bg-[#f5f5f7] flex justify-between items-center">
                      <span className="text-[#86868b]">{item.label}</span>
                      <span className="font-bold text-[#1d1d1f] font-mono text-sm">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Dates & Deadlines */}
            {(displayDoc.extractedInfo?.datesAndDeadlines || []).length > 0 && (
              <div className="apple-card space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#86868b] flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-[#0071e3]" />
                  Dates & Deadlines Schedule
                </h4>

                <div className="space-y-2">
                  {(displayDoc.extractedInfo?.datesAndDeadlines || []).map((item, idx) => (
                    <div
                      key={idx}
                      className={`p-3.5 rounded-[8px] border flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs ${
                        item.isUrgent
                          ? 'bg-rose-50 border-rose-200 text-rose-950'
                          : 'bg-[#f5f5f7] border-[#e5e7eb] text-[#1d1d1f]'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-[#1d1d1f] text-sm">{item.title}</span>
                          {item.isUrgent && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-[980px] bg-rose-200 text-rose-800 uppercase">
                              Urgent
                            </span>
                          )}
                        </div>
                        <p className="text-[#86868b]">{item.importance}</p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="font-mono font-bold text-xs bg-white px-3 py-1 rounded-[6px] border border-[#e5e7eb] text-[#1d1d1f]">
                          {item.date}
                        </span>
                        {item.pageReference && (
                          <button
                            onClick={() => handleJumpToPage(item.pageReference!)}
                            className="text-[#0071e3] hover:underline font-semibold"
                          >
                            P.{item.pageReference}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Financial Figures */}
            <div className="apple-card space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#86868b] flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                Financial Commitments & Fees
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {(displayDoc.extractedInfo?.financialAmounts || []).map((f, idx) => (
                  <div key={idx} className="p-4 rounded-[8px] bg-[#f5f5f7] space-y-1">
                    <span className="text-[12px] font-medium text-[#86868b]">{f.label}</span>
                    <div className="text-2xl font-bold text-emerald-700">{f.amount}</div>
                    {f.recurrence && (
                      <p className="text-[11px] text-[#86868b]">{f.recurrence}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Rights & Obligations */}
            <div className="apple-card space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#86868b] flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-[#0071e3]" />
                Rights, Obligations & Restrictions
              </h4>

              <div className="space-y-2">
                {(displayDoc.extractedInfo?.rightsAndObligations || []).map((item, idx) => {
                  const badge =
                    item.type === 'obligation'
                      ? { bg: 'bg-amber-100 text-amber-800', label: 'Obligation' }
                      : item.type === 'restriction'
                      ? { bg: 'bg-rose-100 text-rose-800', label: 'Restriction' }
                      : { bg: 'bg-emerald-100 text-emerald-800', label: 'Right' };

                  return (
                    <div key={idx} className="p-3.5 rounded-[8px] bg-[#f5f5f7] flex items-start gap-3 text-xs">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-[980px] uppercase shrink-0 ${badge.bg}`}>
                        {badge.label}
                      </span>
                      <div className="flex-1 space-y-0.5">
                        <span className="font-semibold text-[#1d1d1f]">{item.party}</span>
                        <p className="text-[#86868b] leading-relaxed">{item.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* ----------------- TAB 4: TERMINOLOGY ----------------- */}
        {activeTab === 'terminology' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-xl font-bold text-[#1d1d1f]">
                  Key Terminology Glossary
                </h3>
                <p className="text-xs text-[#86868b]">
                  Identified complex words, technical abbreviations, and plain meanings.
                </p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-[#86868b] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={termSearch}
                  onChange={(e) => setTermSearch(e.target.value)}
                  placeholder="Search terms..."
                  className="w-full bg-[#f5f5f7] border border-transparent rounded-[8px] pl-9 pr-3 py-1.5 text-xs text-[#1d1d1f] focus:outline-none focus:bg-white focus:border-[#0071e3]"
                />
              </div>
            </div>

            {displayDoc.terminology.length === 0 ? (
              <div className="apple-card p-8 text-center text-xs text-[#86868b] space-y-1">
                <p className="font-semibold text-[#1d1d1f] text-sm">No complex terminology flagged</p>
                <p>The document uses direct entries without ambiguous technical jargon.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(displayDoc.terminology || [])
                  .filter(
                    (t) =>
                      termSearch === '' ||
                      t.term.toLowerCase().includes(termSearch.toLowerCase()) ||
                      t.simpleMeaning.toLowerCase().includes(termSearch.toLowerCase())
                  )
                  .map((item) => (
                    <div key={item.id} className="apple-card space-y-3 hover:border-[#0071e3] transition-colors">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <span className="text-[11px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-[980px] bg-[#f5f5f7] text-[#86868b]">
                            {item.category}
                          </span>
                          <h4 className="text-base font-bold text-[#1d1d1f] mt-1">
                            {item.term}
                          </h4>
                        </div>

                        <button
                          onClick={() => handleJumpToPage(item.pageReference)}
                          className="text-xs font-semibold text-[#0071e3] hover:underline flex items-center gap-1"
                        >
                          Page {item.pageReference} <ExternalLink className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="p-3 rounded-[8px] bg-emerald-50/70 border border-emerald-200 space-y-1">
                        <span className="text-[10px] font-bold uppercase text-emerald-800">
                          Simple Everyday Meaning
                        </span>
                        <p className="text-xs text-emerald-950 font-medium leading-relaxed">
                          {item.simpleMeaning}
                        </p>
                      </div>

                      <div className="p-3 rounded-[8px] bg-[#f5f5f7] text-xs space-y-1">
                        <span className="font-bold text-[#1d1d1f]">
                          In this Document:
                        </span>
                        <p className="text-[#86868b] leading-relaxed">{item.contextExplanation}</p>
                      </div>
                    </div>
                  ))}
              </div>
            )}

          </div>
        )}

        {/* ----------------- TAB 5: RISKS AND WARNINGS ----------------- */}
        {activeTab === 'risks' && (
          <div className="space-y-6">
            <div className="p-4 rounded-[8px] bg-amber-50 border border-amber-200 text-amber-950 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs space-y-1">
                <span className="font-bold block">Advisory Disclaimer</span>
                <p className="leading-relaxed text-amber-900">
                  Automated observations do not constitute definitive legal, financial, or medical advice. Always consult certified counsel for binding decisions.
                </p>
              </div>
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-bold text-[#1d1d1f]">
                Identified Risks & Potential Concerns
              </h3>
              <p className="text-xs text-[#86868b]">
                Important notices, strict conditions, and key requirements.
              </p>
            </div>

            {(displayDoc.risks || []).length === 0 ? (
              <div className="apple-card p-8 text-center text-xs text-[#86868b] space-y-1">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="font-semibold text-[#1d1d1f] text-sm">No critical risks flagged</p>
                <p>This document contains standard instructions without trap clauses.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {(displayDoc.risks || []).map((risk) => {
                  const badge =
                    risk.severity === 'critical'
                      ? 'bg-rose-100 text-rose-800 border-rose-300'
                      : risk.severity === 'high'
                      ? 'bg-amber-100 text-amber-800 border-amber-300'
                      : 'bg-blue-100 text-blue-800 border-blue-300';

                  return (
                    <div key={risk.id} className="apple-card space-y-3 hover:border-rose-400 transition-colors">
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-[980px] uppercase border ${badge}`}>
                              {risk.severity} Notice
                            </span>
                            <span className="text-[11px] font-semibold text-[#86868b]">
                              {risk.sectionReference}
                            </span>
                          </div>
                          <h4 className="text-base font-bold text-[#1d1d1f]">
                            {risk.title}
                          </h4>
                        </div>

                        <button
                          onClick={() => handleJumpToPage(risk.pageReference)}
                          className="text-xs font-semibold text-[#0071e3] hover:underline flex items-center gap-1 shrink-0"
                        >
                          Page {risk.pageReference} <ExternalLink className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="space-y-2 text-xs">
                        <div className="p-3.5 rounded-[8px] bg-[#f5f5f7] space-y-1">
                          <span className="font-bold text-[#1d1d1f]">
                            Document Directive:
                          </span>
                          <p className="text-[#86868b] leading-relaxed">{risk.explanation}</p>
                        </div>

                        <div className="p-3.5 rounded-[8px] bg-rose-50 border border-rose-200 space-y-1">
                          <span className="font-bold text-rose-900">
                            Why this point matters:
                          </span>
                          <p className="text-rose-950 leading-relaxed">{risk.whyItMatters}</p>
                        </div>

                        <div className="p-3.5 rounded-[8px] bg-emerald-50 border border-emerald-200 space-y-1">
                          <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                            Recommended Action:
                          </span>
                          <p className="text-emerald-950 font-medium leading-relaxed">{risk.recommendedAction}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

        {/* ----------------- TAB 6: ASK AI ASSISTANT ----------------- */}
        {activeTab === 'chat' && (
          <div className="space-y-6 flex flex-col justify-between">
            
            <div className="space-y-4">
              <div className="p-4 rounded-[8px] bg-[#f5f5f7] text-xs text-[#1d1d1f] flex items-start gap-3">
                <Sparkles className="w-4 h-4 text-[#0071e3] shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-[#1d1d1f]">
                    Interactive Grounded Document Assistant
                  </p>
                  <p className="mt-0.5 text-[#86868b]">
                    {`Ask any question about ${displayDoc.title}. Factual answers provide page citations and are explained in ${SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage)?.nativeName}.`}
                  </p>
                </div>
              </div>

              {/* Prompt chips */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-semibold text-[#86868b] uppercase tracking-wider">
                  Suggested questions:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {samplePrompts.map((p, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleAskQuestion(p)}
                      className="text-[12px] font-medium bg-[#f5f5f7] hover:bg-[#e8e8ed] text-[#1d1d1f] px-3.5 py-1.5 rounded-[980px] transition-colors text-left"
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              {/* Message History */}
              <div className="space-y-4 pt-2">
                {(displayDoc.chatHistory || []).map((item) => (
                  <div key={item.id} className="space-y-2">
                    <div className="flex justify-end">
                      <div className="max-w-[85%] rounded-[18px] bg-[#0071e3] text-white px-4 py-2.5 text-xs font-medium">
                        {item.question}
                      </div>
                    </div>

                    <div className="flex justify-start">
                      <div className="max-w-[95%] rounded-[12px] bg-[#f5f5f7] border border-[#e5e7eb] p-5 text-xs text-[#1d1d1f] space-y-3">
                        <div className="flex items-center justify-between text-[11px] text-[#86868b] border-b border-[#e5e7eb] pb-2">
                          <span className="font-bold text-[#0071e3] flex items-center gap-1">
                            <Sparkles className="w-3 h-3" />
                            PaperExplain AI ({SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage)?.nativeName})
                          </span>
                          <span className="capitalize">{item.explanationMode} Mode</span>
                        </div>

                        <div className="whitespace-pre-line leading-relaxed text-[#1d1d1f] text-[13px]">
                          {item.answer}
                        </div>

                        {item.pageReferences && item.pageReferences.length > 0 && (
                          <div className="pt-2 border-t border-[#e5e7eb] flex items-center gap-2 flex-wrap text-[11px]">
                            <span className="text-[#86868b] font-medium">Citations:</span>
                            {item.pageReferences.map((pNum) => (
                              <button
                                key={pNum}
                                onClick={() => handleJumpToPage(pNum)}
                                className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-[980px] bg-white border border-[#0071e3] text-[#0071e3] font-semibold hover:bg-blue-50 transition-colors"
                              >
                                <span>Page {pNum}</span>
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {isAsking && (
                  <div className="flex justify-start">
                    <div className="rounded-[12px] bg-[#f5f5f7] border border-[#e5e7eb] p-4 text-xs text-[#86868b] flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#0071e3] animate-spin" />
                      <span>
                        {currentLanguage === 'mr'
                          ? 'दस्तऐवज वाचून मराठीत विश्लेषण तयार करत आहे...'
                          : currentLanguage === 'hi'
                          ? 'दस्तावेज़ पढ़कर हिंदी में विश्लेषण तैयार किया जा रहा है...'
                          : 'Reading document and synthesizing explanation...'}
                      </span>
                    </div>
                  </div>
                )}
                <div ref={chatBottomRef} />
              </div>
            </div>

            {/* Chat Input Bar */}
            <div className="sticky bottom-0 bg-white pt-2 border-t border-[#e5e7eb]">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleAskQuestion();
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={chatQuestion}
                  onChange={(e) => setChatQuestion(e.target.value)}
                  placeholder="Ask any question about this document..."
                  className="flex-1 bg-[#f5f5f7] border border-transparent rounded-[980px] px-5 py-2.5 text-xs text-[#1d1d1f] placeholder-[#86868b] focus:outline-none focus:bg-white focus:border-[#0071e3]"
                />
                <button
                  type="submit"
                  disabled={!chatQuestion.trim() || isAsking}
                  className="apple-btn-primary !min-h-[38px] !py-[6px] !px-[18px] !text-[14px]"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Ask Document AI</span>
                </button>
              </form>
            </div>

          </div>
        )}
      </>
    );
  }
};
