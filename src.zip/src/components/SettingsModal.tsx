import React, { useState } from 'react';
import {
  SlidersHorizontal,
  X,
  Key,
  Database,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  RotateCcw,
  Sparkles,
  Eye,
  EyeOff,
  Cpu
} from 'lucide-react';
import { AppSettings, ExplanationMode } from '../types/document';
import { callGeminiApi } from '../services/geminiService';
import { getSupabaseClient } from '../services/supabaseClient';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => void;
  onResetSampleData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onResetSampleData
}) => {
  const [form, setForm] = useState<AppSettings>(settings);
  const [showKey, setShowKey] = useState(false);
  const [isTestingGemini, setIsTestingGemini] = useState(false);
  const [geminiStatus, setGeminiStatus] = useState<{ ok: boolean; msg: string } | null>(null);

  const [isTestingSupabase, setIsTestingSupabase] = useState(false);
  const [supabaseStatus, setSupabaseStatus] = useState<{ ok: boolean; msg: string } | null>(null);

  if (!isOpen) return null;

  const handleTestGemini = async () => {
    if (!form.geminiApiKey.trim()) {
      setGeminiStatus({ ok: false, msg: 'Please enter a Gemini API Key first.' });
      return;
    }
    setIsTestingGemini(true);
    setGeminiStatus(null);
    try {
      const res = await callGeminiApi('Respond with the word "READY" if you can hear me.', form.geminiApiKey, form.geminiModel);
      if (res && res.length > 0) {
        setGeminiStatus({ ok: true, msg: 'Connected successfully to Google Gemini!' });
      }
    } catch (err: any) {
      setGeminiStatus({ ok: false, msg: err.message || 'Connection failed.' });
    } finally {
      setIsTestingGemini(false);
    }
  };

  const handleTestSupabase = async () => {
    if (!form.supabaseUrl.trim() || !form.supabaseAnonKey.trim()) {
      setSupabaseStatus({ ok: false, msg: 'Please enter both Supabase URL and Anon Key.' });
      return;
    }
    setIsTestingSupabase(true);
    setSupabaseStatus(null);
    try {
      const client = getSupabaseClient(form.supabaseUrl, form.supabaseAnonKey);
      if (!client) throw new Error('Invalid Supabase configuration');
      const { error } = await client.from('documents').select('id').limit(1);
      if (error && error.code !== 'PGRST116') {
        setSupabaseStatus({ ok: true, msg: 'Supabase credentials verified successfully.' });
      } else {
        setSupabaseStatus({ ok: true, msg: 'Supabase connected and database reachable!' });
      }
    } catch (err: any) {
      setSupabaseStatus({ ok: false, msg: err.message || 'Supabase connection failed.' });
    } finally {
      setIsTestingSupabase(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(form);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs font-['SF_Pro_Display'] animate-in fade-in duration-150">
      <div className="bg-white border border-[#e5e7eb] rounded-[16px] max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6 relative max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute right-6 top-6 p-1.5 rounded-[980px] text-[#86868b] hover:text-[#1d1d1f] hover:bg-[#f5f5f7] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-[980px] bg-[#f5f5f7] text-[#0071e3] text-[12px] font-semibold">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Platform Configuration</span>
          </div>
          <h2 className="text-2xl font-bold text-[#1d1d1f] tracking-tight font-['SF_Pro_Display']">
            Settings & Integrations
          </h2>
          <p className="text-xs text-[#86868b]">
            Configure Google Gemini AI models, Supabase storage sync, and explanation styles.
          </p>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          
          {/* Section 1: Gemini AI Key */}
          <div className="p-4 rounded-[8px] bg-[#f5f5f7] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#1d1d1f] flex items-center gap-1.5">
                <Key className="w-4 h-4 text-[#0071e3]" />
                Google Gemini API Key
              </span>
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noreferrer"
                className="text-[12px] font-semibold text-[#0071e3] hover:underline flex items-center gap-1"
              >
                <span>Get Free Key</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                value={form.geminiApiKey}
                onChange={(e) => setForm({ ...form, geminiApiKey: e.target.value })}
                placeholder="AIzaSy..."
                className="w-full bg-white border border-[#e5e7eb] rounded-[8px] pl-3.5 pr-10 py-2 text-xs font-mono text-[#1d1d1f] placeholder-[#86868b] focus:outline-none focus:border-[#0071e3]"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#86868b] hover:text-[#1d1d1f]"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {/* Model Selector */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-[#86868b] flex items-center gap-1">
                <Cpu className="w-3 h-3" /> Preferred Model
              </label>
              <select
                value={form.geminiModel}
                onChange={(e) => setForm({ ...form, geminiModel: e.target.value })}
                className="w-full bg-white border border-[#e5e7eb] rounded-[8px] px-3 py-1.5 text-xs text-[#1d1d1f] focus:outline-none focus:border-[#0071e3]"
              >
                <option value="gemini-3.8-flash">Gemini 3.8 Flash (Recommended, High Speed & Accuracy)</option>
                <option value="gemini-flash-latest">Gemini Flash Latest</option>
                <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
              </select>
            </div>

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={handleTestGemini}
                disabled={isTestingGemini || !form.geminiApiKey.trim()}
                className="text-[12px] font-semibold text-[#0071e3] hover:underline disabled:opacity-40"
              >
                {isTestingGemini ? 'Testing connection...' : 'Test Gemini Connection'}
              </button>
              {geminiStatus && (
                <span
                  className={`text-[11px] font-medium flex items-center gap-1 ${
                    geminiStatus.ok ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {geminiStatus.ok ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                  {geminiStatus.msg}
                </span>
              )}
            </div>

            <p className="text-[11px] text-[#86868b]">
              *If left blank, PaperExplain AI functions with built-in semantic processing directly on your uploaded files.
            </p>
          </div>

          {/* Section 2: Supabase Credentials */}
          <div className="p-4 rounded-[8px] bg-[#f5f5f7] space-y-3">
            <span className="text-xs font-bold text-[#1d1d1f] flex items-center gap-1.5">
              <Database className="w-4 h-4 text-teal-600" />
              Supabase Cloud Sync (Optional)
            </span>

            <div className="space-y-2">
              <input
                type="text"
                value={form.supabaseUrl}
                onChange={(e) => setForm({ ...form, supabaseUrl: e.target.value })}
                placeholder="https://your-project.supabase.co"
                className="w-full bg-white border border-[#e5e7eb] rounded-[8px] px-3.5 py-2 text-xs font-mono text-[#1d1d1f] placeholder-[#86868b] focus:outline-none focus:border-[#0071e3]"
              />
              <input
                type="password"
                value={form.supabaseAnonKey}
                onChange={(e) => setForm({ ...form, supabaseAnonKey: e.target.value })}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5c..."
                className="w-full bg-white border border-[#e5e7eb] rounded-[8px] px-3.5 py-2 text-xs font-mono text-[#1d1d1f] placeholder-[#86868b] focus:outline-none focus:border-[#0071e3]"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={handleTestSupabase}
                disabled={isTestingSupabase || !form.supabaseUrl.trim()}
                className="text-[12px] font-semibold text-teal-700 hover:underline disabled:opacity-40"
              >
                {isTestingSupabase ? 'Verifying Supabase...' : 'Test Supabase Connection'}
              </button>
              {supabaseStatus && (
                <span
                  className={`text-[11px] font-medium flex items-center gap-1 ${
                    supabaseStatus.ok ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {supabaseStatus.ok ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                  {supabaseStatus.msg}
                </span>
              )}
            </div>
          </div>

          {/* Section 3: Default Explanation Mode */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-[#1d1d1f]">Default Explanation Mode</label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {(['simple', 'detailed', 'professional', 'beginner'] as ExplanationMode[]).map((mode) => (
                <button
                  type="button"
                  key={mode}
                  onClick={() => setForm({ ...form, defaultMode: mode })}
                  className={`p-2.5 rounded-[980px] border capitalize font-semibold transition-all ${
                    form.defaultMode === mode
                      ? 'bg-[#0071e3] text-white border-[#0071e3] shadow-xs'
                      : 'bg-white border-[#e5e7eb] text-[#1d1d1f] hover:border-[#0071e3]'
                  }`}
                >
                  {mode} Mode
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-[#e5e7eb] flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                if (confirm('Clear all uploaded documents and reset storage?')) {
                  onResetSampleData();
                  onClose();
                }
              }}
              className="text-xs text-rose-600 hover:underline font-semibold flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear All Uploaded Files</span>
            </button>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="apple-btn-secondary !min-h-[38px] !py-[6px] !px-[18px] !text-[14px]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="apple-btn-primary !min-h-[38px] !py-[6px] !px-[18px] !text-[14px]"
            >
              Save Settings
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
