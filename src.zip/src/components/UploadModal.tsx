import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  X,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileCode,
  Image,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { parseUploadedFile } from '../services/documentParser';
import { analyzeDocumentWithGemini } from '../services/geminiService';
import { DocumentRecord, DocumentCategory } from '../types/document';
import { CATEGORIES_CONFIG } from '../utils/categories';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDocumentCreated: (doc: DocumentRecord) => void;
  geminiApiKey?: string;
  geminiModel?: string;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onDocumentCreated,
  geminiApiKey,
  geminiModel
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('upload');
  const [dragOver, setDragOver] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressStep, setProgressStep] = useState('');
  const [progressPercent, setProgressPercent] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [pasteTitle, setPasteTitle] = useState('');
  const [pasteCategory, setPasteCategory] = useState<DocumentCategory>('general');
  const [pasteText, setPasteText] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const triggerSuccessConfetti = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {
      // ignore
    }
  };

  const processFile = async (file: File) => {
    setIsProcessing(true);
    setErrorMessage(null);
    setProgressPercent(10);
    setProgressStep(`Reading ${file.name}...`);

    try {
      const parsed = await parseUploadedFile(file);
      setProgressPercent(35);
      setProgressStep('Analyzing document structure and clauses...');

      const record = await analyzeDocumentWithGemini(
        parsed.fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '),
        parsed.fileName,
        parsed.fileSizeFormatted,
        parsed.textByPage,
        parsed.rawText,
        geminiApiKey,
        geminiModel,
        (step, pct) => {
          setProgressStep(step);
          setProgressPercent(pct);
        },
        parsed.imageBase64,
        parsed.imageMimeType,
        parsed.pdfUrl
      );

      triggerSuccessConfetti();
      onDocumentCreated(record);
      onClose();
    } catch (err: any) {
      console.error('File parsing error:', err);
      setErrorMessage(err.message || 'An error occurred during document parsing.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePasteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pasteText.trim()) return;

    setIsProcessing(true);
    setErrorMessage(null);
    setProgressPercent(15);
    setProgressStep('Synthesizing pasted document...');

    try {
      const cleanTitle = pasteTitle.trim() || 'Untitled Document';
      const fileName = `${cleanTitle.toLowerCase().replace(/\s+/g, '_')}.txt`;
      const paragraphs = pasteText.split(/\n\s*\n/).filter((p) => p.trim().length > 0);
      const textByPage = paragraphs.length > 0 ? paragraphs : [pasteText];

      const record = await analyzeDocumentWithGemini(
        cleanTitle,
        fileName,
        `${(pasteText.length / 1024).toFixed(1)} KB`,
        textByPage,
        pasteText,
        geminiApiKey,
        geminiModel,
        (step, pct) => {
          setProgressStep(step);
          setProgressPercent(pct);
        }
      );

      triggerSuccessConfetti();
      onDocumentCreated(record);
      onClose();
    } catch (err: any) {
      console.error('Pasted text analysis error:', err);
      setErrorMessage(err.message || 'Failed to analyze text.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs font-['SF_Pro_Display'] animate-in fade-in duration-150">
      <div className="bg-white border border-[#e5e7eb] rounded-[16px] max-w-xl w-full p-6 sm:p-8 shadow-2xl space-y-5 relative">
        
        <button
          onClick={onClose}
          disabled={isProcessing}
          className="absolute right-6 top-6 p-1.5 rounded-[980px] text-[#86868b] hover:text-[#1d1d1f] hover:bg-[#f5f5f7] transition-colors disabled:opacity-40"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-[980px] bg-[#f5f5f7] text-[#0071e3] text-[12px] font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Universal AI Ingestion</span>
          </div>
          <h2 className="text-2xl font-bold text-[#1d1d1f] tracking-tight font-['SF_Pro_Display']">
            Upload & Understand Any Document
          </h2>
          <p className="text-xs text-[#86868b]">
            Supports PDFs, contracts, scans, medical reports, terms, and plain text.
          </p>
        </div>

        {!isProcessing && (
          <div className="flex items-center bg-[#f5f5f7] p-1 rounded-[980px] text-xs font-semibold text-[#86868b]">
            <button
              onClick={() => setActiveTab('upload')}
              className={`flex-1 py-1.5 rounded-[980px] transition-all ${
                activeTab === 'upload' ? 'bg-white text-[#1d1d1f] shadow-xs' : 'hover:text-[#1d1d1f]'
              }`}
            >
              Upload File (PDF, Scans, TXT)
            </button>
            <button
              onClick={() => setActiveTab('paste')}
              className={`flex-1 py-1.5 rounded-[980px] transition-all ${
                activeTab === 'paste' ? 'bg-white text-[#1d1d1f] shadow-xs' : 'hover:text-[#1d1d1f]'
              }`}
            >
              Paste Document Text
            </button>
          </div>
        )}

        {errorMessage && (
          <div className="p-3.5 rounded-[8px] bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {isProcessing ? (
          <div className="py-10 space-y-4 text-center">
            <div className="w-14 h-14 rounded-[14px] bg-blue-50 border border-blue-200 flex items-center justify-center mx-auto text-[#0071e3] animate-pulse">
              <Sparkles className="w-7 h-7" />
            </div>
            
            <div className="space-y-1">
              <h4 className="text-base font-bold text-[#1d1d1f] font-['SF_Pro_Display']">
                Understanding Document...
              </h4>
              <p className="text-xs text-[#86868b]">{progressStep}</p>
            </div>

            <div className="w-full bg-[#f5f5f7] h-2 rounded-[980px] overflow-hidden max-w-sm mx-auto">
              <div
                style={{ width: `${progressPercent}%` }}
                className="bg-[#0071e3] h-full rounded-[980px] transition-all duration-300"
              />
            </div>
            <p className="text-[11px] text-[#86868b] font-mono">{progressPercent}% complete</p>
          </div>
        ) : activeTab === 'upload' ? (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              const files = e.dataTransfer.files;
              if (files.length > 0) processFile(files[0]);
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-[12px] p-8 sm:p-10 text-center cursor-pointer transition-all space-y-4 ${
              dragOver
                ? 'border-[#0071e3] bg-blue-50/50 scale-[0.99]'
                : 'border-[#e5e7eb] hover:border-[#0071e3] hover:bg-[#f5f5f7]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.txt,.md,.docx,image/*"
              className="hidden"
              onChange={(e) => {
                const files = e.target.files;
                if (files && files.length > 0) processFile(files[0]);
              }}
            />

            <div className="w-12 h-12 rounded-[10px] bg-[#f5f5f7] flex items-center justify-center mx-auto text-[#0071e3]">
              <UploadCloud className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <p className="text-sm font-bold text-[#1d1d1f]">
                Drag and drop your file here, or <span className="text-[#0071e3] underline">browse</span>
              </p>
              <p className="text-xs text-[#86868b]">
                PDF, Word docs, Scanned Receipts, Lab Reports, or Plain Text
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 text-[11px] text-[#86868b]">
              <span className="flex items-center gap-1"><FileText className="w-3.5 h-3.5" /> PDF</span>
              <span>•</span>
              <span className="flex items-center gap-1"><FileCode className="w-3.5 h-3.5" /> TXT</span>
              <span>•</span>
              <span className="flex items-center gap-1"><Image className="w-3.5 h-3.5" /> Scans & Images</span>
            </div>
          </div>
        ) : (
          <form onSubmit={handlePasteSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-[#1d1d1f]">Document Title</label>
              <input
                type="text"
                value={pasteTitle}
                onChange={(e) => setPasteTitle(e.target.value)}
                placeholder="e.g. Master Services Agreement"
                className="w-full bg-[#f5f5f7] border border-transparent rounded-[8px] px-3.5 py-2 text-xs text-[#1d1d1f] focus:outline-none focus:bg-white focus:border-[#0071e3]"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#1d1d1f]">Document Category</label>
              <select
                value={pasteCategory}
                onChange={(e) => setPasteCategory(e.target.value as DocumentCategory)}
                className="w-full bg-[#f5f5f7] border border-transparent rounded-[8px] px-3.5 py-2 text-xs text-[#1d1d1f] focus:outline-none focus:bg-white focus:border-[#0071e3]"
              >
                {Object.entries(CATEGORIES_CONFIG).map(([key, meta]) => (
                  <option key={key} value={key}>
                    {meta.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#1d1d1f]">Document Text</label>
              <textarea
                value={pasteText}
                onChange={(e) => setPasteText(e.target.value)}
                placeholder="Paste the agreement clauses, medical report, or document text here..."
                rows={7}
                className="w-full bg-[#f5f5f7] border border-transparent rounded-[8px] p-3 text-xs text-[#1d1d1f] font-mono leading-relaxed focus:outline-none focus:bg-white focus:border-[#0071e3]"
                required
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="apple-btn-secondary !min-h-[38px] !py-[6px] !px-[18px] !text-[14px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!pasteText.trim()}
                className="apple-btn-primary !min-h-[38px] !py-[6px] !px-[18px] !text-[14px] disabled:opacity-40"
              >
                <Sparkles className="w-4 h-4" />
                <span>Explain Document</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
